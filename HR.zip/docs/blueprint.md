# **App Name**: Vantage GDFSD

## Core Features:

- Holiday-to-Action Engine: An AI-powered tool that analyzes African and Liberian holidays to generate context-specific sustainability action plans and educational significance reports.
- Institutional Resource Vault: A secure, password-protected portal hosted on a professional database for government officials to access MOUs, policy drafts, and sample frameworks.
- ARREST Strategy Matrix: An interactive UI component mapping GDFSD publication features directly to the six pillars of the national ARREST Agenda.
- Framework Intelligence Dashboard: A visual interface displaying interactive badges for SDGs and Agenda 2063 that reveal specific product alignments upon interaction.
- National Impact Map: A dynamic geolocation map of Liberia demonstrating where publications and consultancy programs are active across different counties.
- Official Sample Procurement Portal: A professional triage form designed for Ministry-level sample requests and high-priority governmental outreach.
- Global Heritage Showcase: A high-performance imagery system featuring the 'Legacy' products being utilized in both classrooms and ministerial suites.

## Style Guidelines:

- Primary color: Deep Sovereign Navy (#2a4173), chosen to evoke authority and long-term stability in line with heritage values.
- Background color: Ink Charcoal (#11141a), providing a dark, high-end agency aesthetic suitable for high-level institutional branding.
- Accent color: Celestial Azure (#4cc2e4), an analogous brightness shift to highlight critical calls to action and policy focus points.
- Headline font: 'Playfair Display' (Serif) for a formal, high-end 'legacy' feel; Body font: 'PT Sans' (Sans-serif) for modern clarity and warmth.
- Use custom vector icons that combine the strict geometry of UN SDG symbols with organic West African heritage patterns.
- A wide, generous 12-page 'Portal' structure utilizing micro-animations to create a sense of digital 'movement' towards 2030 and 2063 goals.
- Subtle parallax on framework logos and hero sliders to signify a premium, award-winning digital experience for world leaders.