# Vantage GDFSD | Digital Sustainability Hub

This is the official digital platform for **Generational Demands for Sustainable Development Inc. (GDFSD)**, Liberia's premier consultancy bridging international policy and local action.

## Core Features
- **Legacy Publication Suite:** Interactive exploration of our flagship tools.
- **ARREST Matrix:** Real-time alignment mapping with national strategy.
- **Institutional AI:** AI-powered consultancy previews for ministry leaders.
- **Impact Tracking:** National footprint visualization.

## Technical Overview
- **Framework:** Next.js 15 (App Router)
- **AI Integration:** Genkit with Gemini 2.5 Flash
- **Styling:** Tailwind CSS + ShadCN UI components
- **Design:** Playfair Display (Headlines) & PT Sans (Body)

For full documentation, please refer to [DOCUMENTATION.md](./DOCUMENTATION.md).
