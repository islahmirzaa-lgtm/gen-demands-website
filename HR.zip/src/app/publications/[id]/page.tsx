
"use client"

import React, { use, useMemo } from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useFirestore, useDoc } from '@/firebase'
import { doc } from 'firebase/firestore'
import { ArrowLeft, CheckCircle2, Globe, Loader2 } from 'lucide-react'
import { notFound } from 'next/navigation'

const PublicationDetailPage = ({ params }: { params: Promise<{ id: string }> }) => {
  const resolvedParams = use(params)
  const firestore = useFirestore()
  
  const docRef = useMemo(() => {
    if (!firestore || !resolvedParams.id) return null
    return doc(firestore, 'publications', resolvedParams.id)
  }, [firestore, resolvedParams.id])

  const { data: book, loading } = useDoc<any>(docRef)

  if (!loading && !book) {
    notFound()
  }

  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      
      <div className="pt-32 pb-24 bg-background overflow-hidden relative">
        <div className="container mx-auto px-4 relative z-10">
          <Link href="/publications" className="inline-flex items-center text-accent text-sm font-bold mb-12 hover:translate-x-[-4px] transition-transform">
            <ArrowLeft className="mr-2 w-4 h-4" />
            Back to Publications
          </Link>

          {loading ? (
            <div className="flex justify-center items-center py-24">
              <Loader2 className="w-12 h-12 text-accent animate-spin" />
            </div>
          ) : (
            <div className="grid lg:grid-cols-2 gap-16 items-start">
              <div className="relative group">
                <div className="relative aspect-[3/4] rounded-3xl overflow-hidden shadow-2xl border border-white/10 bg-secondary">
                  <img
                    src={book.imageUrl}
                    alt={book.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="absolute -bottom-6 -right-6 glass-panel p-6 rounded-2xl border-accent/20 animate-in fade-in zoom-in duration-700">
                  <div className="text-3xl font-bold font-headline text-accent">Strategic</div>
                  <div className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">Certified Publication</div>
                </div>
              </div>

              <div className="space-y-8">
                <div>
                  <Badge className="mb-4 bg-accent/20 text-accent border-accent/20 uppercase tracking-widest px-4 py-1">{book.tagline}</Badge>
                  <h1 className="text-5xl md:text-6xl font-headline font-bold mb-6">{book.title}</h1>
                  <p className="text-xl text-muted-foreground leading-relaxed whitespace-pre-wrap">
                    {book.description}
                  </p>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <Button size="lg" className="h-14 bg-accent text-accent-foreground font-bold">Purchase Print Edition</Button>
                  <Button size="lg" variant="outline" className="h-14 border-white/10 hover:bg-white/5">Request Digital Sample</Button>
                </div>

                <Tabs defaultValue="alignment" className="w-full">
                  <TabsList className="grid grid-cols-2 w-full bg-secondary/50 p-1 rounded-xl h-12">
                    <TabsTrigger value="alignment" className="rounded-lg">Framework Alignment</TabsTrigger>
                    <TabsTrigger value="features" className="rounded-lg">Core Features</TabsTrigger>
                  </TabsList>

                  <TabsContent value="alignment" className="mt-8 space-y-4">
                    {book.alignment?.map((a: any, i: number) => (
                      <div key={i} className="p-6 rounded-2xl glass-panel border-white/5 flex items-start space-x-4">
                        <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                          <Globe className="w-5 h-5 text-accent" />
                        </div>
                        <div>
                          <div className="flex items-center space-x-2 mb-1">
                            <span className="font-bold text-accent">{a.framework}</span>
                            <Badge variant="outline" className="text-[10px] border-white/10">{a.pillar}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground leading-relaxed">{a.detail}</p>
                        </div>
                      </div>
                    ))}
                  </TabsContent>

                  <TabsContent value="features" className="mt-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {book.features?.map((f: string, i: number) => (
                        <div key={i} className="flex items-center space-x-3 p-4 rounded-xl bg-white/5 border border-white/5">
                          <CheckCircle2 className="w-5 h-5 text-accent" />
                          <span className="text-sm font-medium">{f}</span>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          )}
        </div>
        
        {/* Background flares */}
        <div className="absolute top-0 right-0 w-1/3 h-1/2 bg-accent/5 blur-[120px] -z-10" />
        <div className="absolute bottom-0 left-0 w-1/4 h-1/2 bg-primary/10 blur-[100px] -z-10" />
      </div>

      <Footer />
    </main>
  )
}

export default PublicationDetailPage
