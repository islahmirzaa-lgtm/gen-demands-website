"use client"

import React from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArrowLeft, BookOpen, Globe, Quote, ShoppingCart, ShieldCheck, History } from 'lucide-react'

const SparkVol1Page = () => {
  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      
      <div className="pt-32 pb-24 bg-background overflow-hidden relative">
        <div className="container mx-auto px-4 relative z-10">
          <Link href="/publications" className="inline-flex items-center text-accent text-sm font-bold mb-12 hover:translate-x-[-4px] transition-transform">
            <ArrowLeft className="mr-2 w-4 h-4" />
            Back to Strategic Library
          </Link>

          <div className="grid lg:grid-cols-12 gap-16 items-start">
            {/* Left: Visual Sidebar */}
            <div className="lg:col-span-4 space-y-8">
              <div className="relative aspect-[3/4] rounded-3xl overflow-hidden shadow-2xl border border-border bg-secondary">
                <img
                  src="https://picsum.photos/seed/history-vol1/800/1000"
                  alt="Liberia: The Spark of Africa's Freedom Vol 1"
                  className="w-full h-full object-cover grayscale"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/80 to-transparent" />
                <div className="absolute bottom-8 left-8 right-8 text-white">
                  <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-accent mb-2">Volume One</p>
                  <h3 className="text-2xl font-headline font-bold">Foundations of Liberty</h3>
                </div>
              </div>

              <Card className="rounded-2xl border-border bg-secondary/20 p-6 space-y-4">
                <div className="flex items-center space-x-3">
                  <ShieldCheck className="w-5 h-5 text-accent" />
                  <span className="text-xs font-bold uppercase tracking-widest">Authorized Edition</span>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] text-muted-foreground uppercase font-bold">ISBN</p>
                  <p className="text-sm font-mono">9798270623180</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] text-muted-foreground uppercase font-bold">Publisher</p>
                  <p className="text-sm">GDFSD Inc. - Monrovia</p>
                </div>
              </Card>
            </div>

            {/* Right: Content Area */}
            <div className="lg:col-span-8 space-y-12">
              <div>
                <Badge className="mb-4 bg-primary text-primary-foreground uppercase tracking-[0.3em] font-bold px-4 py-1">Flagship History Suite</Badge>
                <h1 className="text-5xl md:text-7xl font-headline font-bold mb-6">Liberia: The Spark of <span className="text-accent">Africa’s Freedom</span></h1>
                <p className="text-xl text-primary font-headline italic border-l-4 border-accent pl-6 py-2">
                  "Before Africa was free, Liberia stood free. And because it stood, Africa rose - a truth that must now guide Africa forward."
                </p>
              </div>

              <Tabs defaultValue="dedication" className="w-full">
                <TabsList className="flex flex-wrap h-auto bg-secondary/50 p-1 rounded-xl mb-8 border border-border/50">
                  <TabsTrigger value="dedication" className="px-6 py-2 rounded-lg text-[10px] uppercase font-bold tracking-widest">Dedication</TabsTrigger>
                  <TabsTrigger value="epigraph" className="px-6 py-2 rounded-lg text-[10px] uppercase font-bold tracking-widest">Epigraph</TabsTrigger>
                  <TabsTrigger value="preface" className="px-6 py-2 rounded-lg text-[10px] uppercase font-bold tracking-widest">Preface</TabsTrigger>
                  <TabsTrigger value="introduction" className="px-6 py-2 rounded-lg text-[10px] uppercase font-bold tracking-widest">Introduction</TabsTrigger>
                </TabsList>

                <TabsContent value="dedication" className="animate-in fade-in slide-in-from-bottom-4">
                  <div className="prose prose-lg text-muted-foreground leading-relaxed">
                    <p className="italic font-medium text-primary">"This book is dedicated to Liberia, Africa’s first independent republic, whose freedom did not end at its borders, but radiated outward to help awaken a dark continent."</p>
                    <p>Before Africa stood free, Liberia stood firm. At a time when Africa was silenced by colonial rule, Liberia spoke boldly, consistently, and unapologetically for African dignity, self-determination, and unity.</p>
                    <p>From diplomacy to safe harbor, from mediation to moral leadership, Liberia used its sovereignty not as a shield for isolation but as a tool for collective African liberation.</p>
                    <p>This dedication also serves as a reminder to African nations, policymakers, educators, and the African Union that Liberia’s history is African history. It is not a footnote, not a marginal story, and not a national tale confined to one coastline.</p>
                  </div>
                </TabsContent>

                <TabsContent value="epigraph" className="animate-in fade-in slide-in-from-bottom-4">
                  <div className="p-12 bg-primary text-primary-foreground relative overflow-hidden border-l-8 border-accent">
                    <Quote className="absolute top-8 right-8 w-16 h-16 text-accent opacity-20" />
                    <div className="relative z-10 space-y-6">
                      <h3 className="text-3xl font-headline font-bold italic leading-tight">
                        "Freedom is not measured by the moment it is claimed, but by how boldly it is shared."
                      </h3>
                      <p className="opacity-80 text-sm leading-relaxed max-w-2xl">
                        Long before the drums of independence echoed across Africa, a small republic stood on the Atlantic shore, free in law, tested in purpose, and burdened with history’s rare responsibility. Liberia’s independence was not an ending; it was an opening, a signal fire lit in 1847.
                      </p>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="preface" className="animate-in fade-in slide-in-from-bottom-4">
                  <div className="prose prose-lg text-muted-foreground leading-relaxed">
                    <p>Africa’s path to freedom did not start suddenly in the twentieth century. Long before independence spread across the continent, Liberia gained independence in 1847, establishing itself as an African republic, asserting sovereignty while much of Africa still remained under colonial control.</p>
                    <p>Written for students, educators, policymakers, and African citizens, this book argues that Africa cannot fully understand its past or confidently build its future without understanding Liberia’s role. As the continent advances toward Agenda 2063: The Africa We Want, Liberia’s experience offers enduring lessons in unity, diplomacy, and a shared destiny.</p>
                  </div>
                </TabsContent>

                <TabsContent value="introduction" className="animate-in fade-in slide-in-from-bottom-4">
                  <div className="prose prose-lg text-muted-foreground leading-relaxed">
                    <p>Liberia: The Spark of Africa’s Freedom (1847–Today) tells a vital, often overlooked story. Before independence, Liberia was free and contributed to Africa's rise. The 1847-coin symbolized liberty for both the nation and the continent.</p>
                    <p>Liberia’s journey started in 1822 when formerly enslaved people returned to build a nation based on liberty. It declared independence in 1847, before most African countries. Despite limited resources, Liberia was symbolically significant. While colonial powers divided Africa, Liberia remained sovereign, supporting liberation efforts, petitioning global bodies, and backing African freedom movements from the League of Nations to Pan-African conferences.</p>
                  </div>
                </TabsContent>
              </Tabs>

              <div className="pt-12 border-t border-border flex flex-col sm:flex-row gap-6">
                <Button size="lg" className="h-16 px-10 bg-accent text-accent-foreground font-bold uppercase tracking-widest text-xs rounded-none shadow-xl" asChild>
                  <Link href="/services/apply">
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Order to Continue
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="h-16 px-10 border-primary text-primary font-bold uppercase tracking-widest text-xs rounded-none" asChild>
                  <Link href="/publications/spark-of-freedom-vol2">
                    Next: Modern Era (Vol 2)
                    <ArrowLeft className="ml-2 w-4 h-4 rotate-180" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}

import { Card } from '@/components/ui/card'
export default SparkVol1Page