"use client"

import React from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArrowLeft, History, Quote, ShoppingCart, ShieldCheck, Landmark } from 'lucide-react'
import { Card } from '@/components/ui/card'

const SparkVol2Page = () => {
  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      
      <div className="pt-32 pb-24 bg-background overflow-hidden relative">
        <div className="container mx-auto px-4 relative z-10">
          <Link href="/publications" className="inline-flex items-center text-accent text-sm font-bold mb-12 hover:translate-x-[-4px] transition-transform">
            <ArrowLeft className="mr-2 w-4 h-4" />
            Back to Strategic Library
          </Link>

          <div className="grid lg:grid-cols-12 gap-16 items-start">
            <div className="lg:col-span-4 space-y-8">
              <div className="relative aspect-[3/4] rounded-3xl overflow-hidden shadow-2xl border border-border bg-primary">
                <img
                  src="https://picsum.photos/seed/history-vol2/800/1000"
                  alt="Liberia: The Spark of Africa's Freedom Vol 2"
                  className="w-full h-full object-cover grayscale opacity-60"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary to-transparent" />
                <div className="absolute bottom-8 left-8 right-8 text-white">
                  <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-accent mb-2">Volume Two</p>
                  <h3 className="text-2xl font-headline font-bold">The Modern Era</h3>
                </div>
              </div>

              <Card className="rounded-2xl border-border bg-secondary/20 p-6 space-y-4">
                <div className="flex items-center space-x-3">
                  <Landmark className="w-5 h-5 text-accent" />
                  <span className="text-xs font-bold uppercase tracking-widest text-primary">Modern Strategic Analysis</span>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] text-muted-foreground uppercase font-bold">Publication Date</p>
                  <p className="text-sm font-bold">May 2026</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] text-muted-foreground uppercase font-bold">Technical ISBN</p>
                  <p className="text-sm font-mono">9798270623180</p>
                </div>
              </Card>
            </div>

            <div className="lg:col-span-8 space-y-12">
              <div>
                <Badge className="mb-4 bg-accent text-accent-foreground uppercase tracking-[0.3em] font-bold px-4 py-1">Strategic Sequel</Badge>
                <h1 className="text-5xl md:text-7xl font-headline font-bold mb-6 text-primary">The Modern <span className="text-accent italic">Resilience.</span></h1>
                <p className="text-xl text-primary font-headline italic border-l-4 border-accent pl-6 py-2">
                  "A nation is not defined by its trials alone, but by how it rises to transform them into purpose."
                </p>
              </div>

              <Tabs defaultValue="dedication" className="w-full">
                <TabsList className="flex flex-wrap h-auto bg-secondary/50 p-1 rounded-xl mb-8 border border-border/50">
                  <TabsTrigger value="dedication" className="px-6 py-2 rounded-lg text-[10px] uppercase font-bold tracking-widest">Dedication</TabsTrigger>
                  <TabsTrigger value="epigraph" className="px-6 py-2 rounded-lg text-[10px] uppercase font-bold tracking-widest">Epigraph</TabsTrigger>
                  <TabsTrigger value="prologue" className="px-6 py-2 rounded-lg text-[10px] uppercase font-bold tracking-widest">Prologue</TabsTrigger>
                  <TabsTrigger value="introduction" className="px-6 py-2 rounded-lg text-[10px] uppercase font-bold tracking-widest">Introduction</TabsTrigger>
                </TabsList>

                <TabsContent value="dedication" className="animate-in fade-in slide-in-from-bottom-4">
                  <div className="prose prose-lg text-muted-foreground leading-relaxed">
                    <p className="italic font-medium text-primary">"This Book is dedicated to Liberia's resilient people, past, present, and future, whose courage, sacrifices, and hope have shaped a nation that stands as a beacon of African freedom."</p>
                    <p>From independent architects to countless unnamed men, women, and youth who bear the weight of history, your stories are the heartbeat of this book.</p>
                    <p>I dedicate this to Liberia's survivors of conflict and loss who chose resilience, reconciliation, and rebuilding. Your strength turned tragedy into renewal, showing Liberia’s spirit remains strong even in dark hours.</p>
                    <p>To visionary leaders and Pan-African champions who placed Liberia at the crossroads of global politics, opposed apartheid and racial injustice, and advanced African unity, your legacy endures.</p>
                  </div>
                </TabsContent>

                <TabsContent value="epigraph" className="animate-in fade-in slide-in-from-bottom-4">
                  <div className="p-12 bg-secondary/30 relative overflow-hidden border-l-8 border-primary">
                    <Quote className="absolute top-8 right-8 w-16 h-16 text-primary opacity-5" />
                    <div className="relative z-10 space-y-6">
                      <h3 className="text-3xl font-headline font-bold italic leading-tight text-primary">
                        “A nation is not defined by its trials alone, but by how it rises to transform them into purpose.”
                      </h3>
                      <p className="text-muted-foreground text-sm leading-relaxed max-w-2xl">
                        Liberia’s journey reflects the strength of a people who have navigated global pressures, resisted injustice, endured conflict, and rebuilt with resolve. From the Cold War crossroads to the fight against apartheid, and from civil war to national renewal, its story is one of resilience and responsibility.
                      </p>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="prologue" className="animate-in fade-in slide-in-from-bottom-4">
                  <div className="prose prose-lg text-muted-foreground leading-relaxed">
                    <p>History speaks through moments of challenge and choice, and Liberia’s journey is one of resilience at the crossroads of global influence and internal transformation.</p>
                    <p>From navigating Cold War tensions to standing firmly against apartheid, the nation has played a meaningful role in advancing justice and African dignity. The years of civil conflict tested Liberia’s foundations, yet they also revealed the strength of a people determined to rebuild.</p>
                  </div>
                </TabsContent>

                <TabsContent value="introduction" className="animate-in fade-in slide-in-from-bottom-4">
                  <div className="prose prose-lg text-muted-foreground leading-relaxed">
                    <p>Beginning with the Cold War era, this book examines how Liberia balanced global alliances while preserving its sovereignty and identity. It highlights the nation’s principled stand against apartheid, affirming its commitment to justice and African solidarity.</p>
                    <p>Moving forward, the narrative captures Liberia’s recovery and forward-looking vision. From rebuilding after the war to aligning with continental frameworks such as Agenda 2063, strengthening regional leadership through ECOWAS, and engaging in global development efforts under the Sustainable Development Goals, Liberia emerges as a nation actively shaping its future.</p>
                  </div>
                </TabsContent>
              </Tabs>

              <div className="pt-12 border-t border-border flex flex-col sm:flex-row gap-6">
                <Button size="lg" className="h-16 px-10 bg-primary text-primary-foreground font-bold uppercase tracking-widest text-xs rounded-none shadow-xl" asChild>
                  <Link href="/services/apply">
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Order to Continue
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="h-16 px-10 border-primary text-primary font-bold uppercase tracking-widest text-xs rounded-none" asChild>
                  <Link href="/publications/spark-of-freedom-vol1">
                    <ArrowLeft className="mr-2 w-4 h-4" />
                    Back to Volume One
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}

export default SparkVol2Page