"use client"

import React from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArrowLeft, GraduationCap, Quote, ShoppingCart, ShieldCheck, Zap, BookOpen } from 'lucide-react'
import { Card } from '@/components/ui/card'

const DreamToDestinyPage = () => {
  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      
      <div className="pt-32 pb-24 bg-background overflow-hidden relative">
        <div className="container mx-auto px-4 relative z-10">
          <Link href="/publications" className="inline-flex items-center text-accent text-sm font-bold mb-12 hover:translate-x-[-4px] transition-transform">
            <ArrowLeft className="mr-2 w-4 h-4" />
            Back to Strategic Library
          </Link>

          <div className="grid lg:grid-cols-12 gap-16 items-start">
            <div className="lg:col-span-4 space-y-8">
              <div className="relative aspect-[3/4] rounded-3xl overflow-hidden shadow-2xl border border-accent/20 bg-secondary/50">
                <img
                  src="https://picsum.photos/seed/destiny-vol1/800/1000"
                  alt="From Dream to Destiny"
                  className="w-full h-full object-cover grayscale"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-accent/40 to-transparent" />
                <div className="absolute bottom-8 left-8 right-8 text-primary">
                  <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-accent mb-2">Civic Blueprint</p>
                  <h3 className="text-2xl font-headline font-bold">The Architect's Guide</h3>
                </div>
              </div>

              <Card className="rounded-2xl border-accent/20 bg-accent/5 p-6 space-y-4">
                <div className="flex items-center space-x-3">
                  <Zap className="w-5 h-5 text-accent" />
                  <span className="text-xs font-bold uppercase tracking-widest text-primary">Youth Engagement Protocol</span>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] text-muted-foreground uppercase font-bold">Standard</p>
                  <p className="text-sm">WAEC & BECE Aligned</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] text-muted-foreground uppercase font-bold">ISBN</p>
                  <p className="text-sm font-mono text-primary">9798277804735</p>
                </div>
              </Card>
            </div>

            <div className="lg:col-span-8 space-y-12">
              <div>
                <Badge className="mb-4 bg-primary text-primary-foreground uppercase tracking-[0.3em] font-bold px-4 py-1">Flagship Civic Blueprint</Badge>
                <h1 className="text-5xl md:text-7xl font-headline font-bold mb-6 text-primary">From Dream to <span className="text-accent italic">Destiny.</span></h1>
                <p className="text-xl text-primary font-headline italic border-l-4 border-accent pl-6 py-2">
                  "A continent does not rise when its elders remember; it rises when its youth imagine, prepare, and act."
                </p>
              </div>

              <Tabs defaultValue="dedication" className="w-full">
                <TabsList className="flex flex-wrap h-auto bg-secondary/50 p-1 rounded-xl mb-8 border border-border/50">
                  <TabsTrigger value="dedication" className="px-6 py-2 rounded-lg text-[10px] uppercase font-bold tracking-widest">Dedication</TabsTrigger>
                  <TabsTrigger value="epigraph" className="px-6 py-2 rounded-lg text-[10px] uppercase font-bold tracking-widest">Epigraph</TabsTrigger>
                  <TabsTrigger value="preface" className="px-6 py-2 rounded-lg text-[10px] uppercase font-bold tracking-widest">Preface</TabsTrigger>
                  <TabsTrigger value="chapter1" className="px-6 py-2 rounded-lg text-[10px] uppercase font-bold tracking-widest">Chapter 1 Preview</TabsTrigger>
                </TabsList>

                <TabsContent value="dedication" className="animate-in fade-in slide-in-from-bottom-4">
                  <div className="prose prose-lg text-muted-foreground leading-relaxed">
                    <p className="italic font-medium text-primary">"This book honors every young African who has dared to imagine a better future despite hardships, those who have chosen hope over resignation despite their nation’s struggles."</p>
                    <p>To students studying by candlelight, innovators creating with limited resources, volunteers restoring dignity in overlooked communities, and brave voices emphasizing integrity, peace, and justice, you are the silent revolution shaping history.</p>
                    <p>This book is dedicated to a generation that refuses to wait for tomorrow to lead, because the Africa We Want must be built, not inherited. May your dreams become blueprints, your actions milestones, and your destiny the continent’s pivotal turning point.</p>
                  </div>
                </TabsContent>

                <TabsContent value="epigraph" className="animate-in fade-in slide-in-from-bottom-4">
                  <div className="p-12 bg-accent/5 relative overflow-hidden border-r-8 border-accent">
                    <Quote className="absolute top-8 left-8 w-16 h-16 text-accent opacity-20 rotate-180" />
                    <div className="relative z-10 space-y-6 text-right">
                      <h3 className="text-3xl font-headline font-bold italic leading-tight text-primary">
                        “Destiny is never delivered; it is built, reclaimed, and carried forward by those who believe tomorrow begins today.”
                      </h3>
                      <p className="text-muted-foreground text-sm leading-relaxed max-w-2xl ml-auto">
                        Across Africa, dreams are no longer quiet whispers but active blueprints realized in classrooms, markets, and digital spaces. A new generation at the crossroads of history and possibility refuses to inherit a future they did not create.
                      </p>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="preface" className="animate-in fade-in slide-in-from-bottom-4">
                  <div className="prose prose-lg text-muted-foreground leading-relaxed">
                    <p>Africa faces a crucial moment with its youth leading the way. "From Dream to Destiny" reflects a truth: Africa's future relies on young people recognizing their strength, understanding their purpose, and taking action.</p>
                    <p>Inspired by Agenda 2063: The Africa We Want, it urges readers to move from dreaming about change to actively creating it. These pages aim to foster courage and awareness, and to remind young Africans that destiny is built, step by step, choice by choice, starting now.</p>
                  </div>
                </TabsContent>

                <TabsContent value="chapter1" className="animate-in fade-in slide-in-from-bottom-4">
                  <div className="p-8 bg-secondary/20 rounded-2xl border border-border">
                    <h3 className="text-2xl font-headline font-bold mb-6 text-primary">Chapter 1: Foundations of Citizenship</h3>
                    <div className="prose prose-sm text-muted-foreground leading-relaxed max-h-[400px] overflow-y-auto pr-4 custom-scrollbar">
                      <p className="italic mb-6">"Picture this: it’s a hot Monday morning in Sanniquellie, Nimba County, Liberia. I’m standing under the shade of a flamboyant tree, watching a group of secondary-school students repaint the walls of a neglected community library..."</p>
                      <p>In this opening chapter, we’ll unpack the big idea behind civic education and link it directly to your everyday life. You will discover:</p>
                      <ul className="space-y-4">
                        <li className="flex items-start space-x-3">
                          <Badge variant="outline" className="mt-1">01</Badge>
                          <span>Why civic education is more than memorizing definitions for WAEC or BECE.</span>
                        </li>
                        <li className="flex items-start space-x-3">
                          <Badge variant="outline" className="mt-1">02</Badge>
                          <span>How the concept of “citizenship” has evolved from ancient Africa to the digital age.</span>
                        </li>
                        <li className="flex items-start space-x-3">
                          <Badge variant="outline" className="mt-1">03</Badge>
                          <span>The rights you can claim, and the responsibilities you must shoulder in modern African democracies.</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>

              <div className="pt-12 border-t border-border flex flex-col sm:flex-row gap-6">
                <Button size="lg" className="h-16 px-10 bg-accent text-accent-foreground font-bold uppercase tracking-widest text-xs rounded-none shadow-xl" asChild>
                  <Link href="/services/apply">
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Order to Continue
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="h-16 px-10 border-primary text-primary font-bold uppercase tracking-widest text-xs rounded-none" asChild>
                  <Link href="/publications">
                    <BookOpen className="w-4 h-4 mr-2" />
                    Back to Library
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}

export default DreamToDestinyPage