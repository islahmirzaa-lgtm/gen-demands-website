
"use client"

import React, { useMemo } from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { useFirestore, useCollection } from '@/firebase'
import { collection, query, orderBy } from 'firebase/firestore'
import { ArrowRight, BookOpen, Shield, GraduationCap, History, Loader2, Quote, BookMarked, Globe, FileText, ShoppingCart } from 'lucide-react'

const Categories = [
  { 
    id: "history", 
    name: "National Identity & History", 
    icon: History, 
    description: "Reclaiming the African narrative through meticulous historical documentation.",
    color: "text-accent"
  },
  { 
    id: "governance", 
    name: "Institutional Governance", 
    icon: Shield, 
    description: "Strategic frameworks for executive leadership and institutional accountability.",
    color: "text-primary"
  },
  { 
    id: "civic", 
    name: "Civic Blueprint", 
    icon: GraduationCap, 
    description: "Empowering the next generation through Pan-African values and civic responsibility.",
    color: "text-accent"
  },
  { 
    id: "professional", 
    name: "Professional Excellence", 
    icon: BookOpen, 
    description: "Technical manuals for security, justice, and professional communication.",
    color: "text-primary"
  }
]

const PublicationsPage = () => {
  const firestore = useFirestore()
  
  const publicationsQuery = useMemo(() => {
    if (!firestore) return null
    return query(collection(firestore, 'publications'), orderBy('createdAt', 'desc'))
  }, [firestore])

  const { data: publications, loading } = useCollection<any>(publicationsQuery)

  const groupedPublications = useMemo(() => {
    if (!publications) return {}
    return publications.reduce((acc: any, pub: any) => {
      const cat = pub.category?.toLowerCase() || 'professional'
      let mappedCat = 'professional'
      if (cat.includes('history')) mappedCat = 'history'
      else if (cat.includes('governance') || cat.includes('sustainability')) mappedCat = 'governance'
      else if (cat.includes('civic') || cat.includes('student') || cat.includes('destiny')) mappedCat = 'civic'
      
      if (!acc[mappedCat]) acc[mappedCat] = []
      acc[mappedCat].push(pub)
      return acc
    }, {})
  }, [publications])

  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Hero */}
      <div className="pt-32 pb-24 bg-primary text-primary-foreground relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl">
            <Badge className="mb-4 bg-accent text-accent-foreground uppercase tracking-[0.3em] px-6 py-1.5 rounded-none font-bold">The Strategic Library</Badge>
            <h1 className="text-5xl md:text-8xl font-headline font-bold mb-8 leading-tight">Legacy Tools <br />for <span className="text-accent italic">Transformation.</span></h1>
            <p className="text-xl opacity-80 leading-relaxed max-w-2xl border-l border-white/20 pl-8 py-2">
              Our publications serve as the technical and historical foundation for a continent that remembers its past, governs with integrity, and shapes its future.
            </p>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-1/2 h-full bg-accent/5 blur-[150px] -z-0" />
      </div>

      <div className="py-24 bg-background">
        <div className="container mx-auto px-4">
          
          {loading ? (
            <div className="flex justify-center items-center py-24">
              <Loader2 className="w-12 h-12 text-accent animate-spin" />
            </div>
          ) : (
            <div className="space-y-32">
              {Categories.map((category) => (
                <section key={category.id} className="scroll-mt-32">
                  <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8 border-b border-border pb-8">
                    <div className="max-w-2xl">
                      <div className="flex items-center space-x-3 mb-4">
                        <category.icon className={`w-8 h-8 ${category.color}`} />
                        <h2 className="text-3xl md:text-4xl font-headline font-bold uppercase tracking-tight">{category.name}</h2>
                      </div>
                      <p className="text-muted-foreground text-lg italic">{category.description}</p>
                    </div>
                  </div>

                  {/* Flagship Spotlight for History Section */}
                  {category.id === 'history' && (
                    <div className="space-y-32">
                      {/* VOLUME ONE SPOTLIGHT */}
                      <div className="p-12 lg:p-20 bg-secondary/10 border border-border relative overflow-hidden group">
                        <div className="grid lg:grid-cols-2 gap-16 relative z-10">
                          <div className="space-y-8">
                            <div>
                              <Badge className="mb-4 bg-primary text-primary-foreground uppercase tracking-[0.3em] font-bold px-4 py-1">Flagship History Suite</Badge>
                              <h3 className="text-4xl md:text-5xl font-headline font-bold leading-tight">Liberia: The Spark of Africa’s Freedom <span className="text-accent">(1847–Today)</span></h3>
                              <p className="text-sm font-bold uppercase tracking-[0.4em] text-muted-foreground mt-2">Volume One: Foundations</p>
                            </div>
                            
                            <div className="space-y-6">
                              <div className="relative p-8 bg-background border-l-4 border-accent shadow-sm">
                                <Quote className="w-8 h-8 text-accent/20 absolute top-4 right-4" />
                                <h4 className="text-[10px] font-bold uppercase tracking-widest text-accent mb-2">Epigraph</h4>
                                <p className="text-lg font-headline font-bold italic leading-relaxed text-primary">
                                  "Freedom is not measured by the moment it is claimed, but by how boldly it is shared."
                                </p>
                              </div>

                              <div className="prose prose-sm text-muted-foreground leading-relaxed max-h-[300px] overflow-y-auto pr-4 custom-scrollbar">
                                <h4 className="text-foreground font-bold uppercase tracking-widest text-[10px] mb-4">Dedication & Preface</h4>
                                <p className="italic mb-4 font-medium">
                                  "This book is dedicated to Liberia, Africa’s first independent republic, whose freedom did not end at its borders, but radiated outward to help awaken a dark continent."
                                </p>
                                <p className="mb-4">
                                  Africa’s path to freedom did not start suddenly in the twentieth century. Long before independence spread across the continent, Liberia established itself as an African republic in 1847, asserting sovereignty while much of Africa remained under colonial control.
                                </p>
                                <p>
                                  Traced through diplomacy, safe harbor, and moral leadership, Liberia used its sovereignty not as a shield for isolation but as a tool for collective African liberation. To forget Liberia’s role is to weaken Africa’s collective memory.
                                </p>
                              </div>
                            </div>

                            <div className="pt-6 flex flex-col sm:flex-row gap-4">
                              <Button variant="outline" className="h-14 px-8 border-primary text-primary hover:bg-primary hover:text-primary-foreground font-bold uppercase tracking-widest text-xs rounded-none" asChild>
                                <Link href="/publications/spark-of-freedom-vol1">
                                  <FileText className="w-4 h-4 mr-2" />
                                  Read More
                                </Link>
                              </Button>
                              <Button className="h-14 px-8 bg-accent text-accent-foreground font-bold uppercase tracking-widest text-xs rounded-none" asChild>
                                <Link href="/services/apply">
                                  <ShoppingCart className="w-4 h-4 mr-2" />
                                  Order to Continue
                                </Link>
                              </Button>
                            </div>
                          </div>

                          <div className="relative">
                            <div className="aspect-[3/4] bg-white border border-border overflow-hidden shadow-2xl relative">
                              <img 
                                src="https://picsum.photos/seed/history-vol1/800/1000" 
                                alt="Liberia: The Spark of Freedom Vol 1" 
                                className="w-full h-full object-cover grayscale opacity-80 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-1000"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-primary/60 via-transparent to-transparent" />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* VOLUME TWO SPOTLIGHT */}
                      <div className="p-12 lg:p-20 bg-primary text-primary-foreground border border-border relative overflow-hidden group">
                        <div className="grid lg:grid-cols-2 gap-16 relative z-10">
                          <div className="space-y-8">
                            <div>
                              <Badge className="mb-4 bg-accent text-accent-foreground uppercase tracking-[0.3em] font-bold px-4 py-1">Strategic Sequel</Badge>
                              <h3 className="text-4xl md:text-5xl font-headline font-bold leading-tight">Liberia: The Spark of Africa’s Freedom <span className="text-accent">(1847–Today)</span></h3>
                              <p className="text-sm font-bold uppercase tracking-[0.4em] text-white/60 mt-2">Volume Two: The Modern Era</p>
                            </div>
                            
                            <div className="space-y-6">
                              <div className="relative p-8 bg-white/5 border-l-4 border-accent shadow-lg backdrop-blur-sm">
                                <Quote className="w-8 h-8 text-accent/20 absolute top-4 right-4" />
                                <h4 className="text-[10px] font-bold uppercase tracking-widest text-accent mb-2">Epigraph</h4>
                                <p className="text-lg font-headline font-bold italic leading-relaxed text-white">
                                  "A nation is not defined by its trials alone, but by how it rises to transform them into purpose."
                                </p>
                              </div>

                              <div className="prose prose-sm prose-invert text-white/70 leading-relaxed max-h-[300px] overflow-y-auto pr-4 custom-scrollbar">
                                <h4 className="text-white font-bold uppercase tracking-widest text-[10px] mb-4">Dedication & Introduction</h4>
                                <p className="italic mb-4">
                                  "This book is dedicated to Liberia's resilient people, past, present, and future, whose courage, sacrifices, and hope have shaped a nation that stands as a beacon of African freedom."
                                </p>
                                <p className="mb-4">
                                  Volume II explores the transformative period where Liberia navigated Cold War tensions and stood firmly against apartheid, affirming its commitment to justice and African solidarity.
                                </p>
                                <p>
                                  It addresses the difficult years of civil conflict, presenting them not only as crisis but as a turning point for renewal, unity, and inclusive governance aligned with Agenda 2063.
                                </p>
                              </div>
                            </div>

                            <div className="pt-6 flex flex-col sm:flex-row gap-4">
                              <Button variant="outline" className="h-14 px-8 border-white/20 text-white hover:bg-white hover:text-primary font-bold uppercase tracking-widest text-xs rounded-none" asChild>
                                <Link href="/publications/spark-of-freedom-vol2">
                                  <FileText className="w-4 h-4 mr-2" />
                                  Read More
                                </Link>
                              </Button>
                              <Button className="h-14 px-8 bg-accent text-accent-foreground font-bold uppercase tracking-widest text-xs rounded-none" asChild>
                                <Link href="/services/apply">
                                  <ShoppingCart className="w-4 h-4 mr-2" />
                                  Order to Continue
                                </Link>
                              </Button>
                            </div>
                          </div>

                          <div className="relative">
                            <div className="aspect-[3/4] bg-white/10 border border-white/10 overflow-hidden shadow-2xl relative">
                              <img 
                                src="https://picsum.photos/seed/history-vol2/800/1000" 
                                alt="Liberia: The Spark of Freedom Vol 2" 
                                className="w-full h-full object-cover grayscale opacity-80 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-1000"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Flagship Spotlight for Civic Section */}
                  {category.id === 'civic' && (
                    <div className="mb-24 p-12 lg:p-20 bg-accent/5 border border-accent/20 relative overflow-hidden group">
                      <div className="grid lg:grid-cols-2 gap-16 relative z-10">
                         <div className="relative order-2 lg:order-1">
                            <div className="aspect-[3/4] bg-primary/10 border border-border overflow-hidden shadow-2xl relative">
                              <img 
                                src="https://picsum.photos/seed/destiny-vol1/800/1000" 
                                alt="From Dream to Destiny Vol 1" 
                                className="w-full h-full object-cover grayscale opacity-80 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-1000"
                              />
                            </div>
                         </div>

                         <div className="space-y-8 order-1 lg:order-2">
                           <div>
                             <Badge className="mb-4 bg-primary text-primary-foreground uppercase tracking-[0.3em] font-bold px-4 py-1">Flagship Civic Blueprint</Badge>
                             <h3 className="text-4xl md:text-5xl font-headline font-bold leading-tight">From Dream to Destiny: <br /><span className="text-accent italic">Youth, the Architects of “The Africa We Want”</span></h3>
                           </div>
                           
                           <div className="space-y-6">
                              <div className="relative p-8 bg-secondary/30 border-r-4 border-accent shadow-lg text-right">
                                <Quote className="w-8 h-8 text-accent/20 absolute top-4 left-4 rotate-180" />
                                <h4 className="text-[10px] font-bold uppercase tracking-widest text-accent mb-2">Epigraph</h4>
                                <p className="text-lg font-headline font-bold italic leading-relaxed text-primary">
                                  "A continent does not rise when its elders remember; it rises when its youth imagine, prepare, and act."
                                </p>
                              </div>

                              <div className="prose prose-sm text-muted-foreground leading-relaxed max-h-[300px] overflow-y-auto pr-4 custom-scrollbar text-right">
                                <h4 className="text-foreground font-bold uppercase tracking-widest text-[10px] mb-4">Dedication & Preface</h4>
                                <p className="italic mb-4">
                                  "This book honors every young African who has dared to imagine a better future despite hardships, those who have chosen hope over resignation."
                                </p>
                                <p className="mb-4">
                                  Africa's future relies on young people recognizing their strength and taking action. From classrooms to digital spaces, youth are the silent revolution shaping history.
                                </p>
                                <p>
                                  Departing from traditional models, this book connects civic concepts to lived African realities—from traffic lights in Monrovia to youth movements across the continent.
                                </p>
                              </div>
                           </div>

                           <div className="pt-6 flex flex-col sm:flex-row gap-4 justify-end">
                              <Button variant="outline" className="h-14 px-8 border-accent text-accent hover:bg-accent hover:text-accent-foreground font-bold uppercase tracking-widest text-xs rounded-none" asChild>
                                <Link href="/publications/dream-to-destiny">
                                  <FileText className="w-4 h-4 mr-2" />
                                  Read More
                                </Link>
                              </Button>
                              <Button className="h-14 px-8 bg-primary text-primary-foreground font-bold uppercase tracking-widest text-xs rounded-none" asChild>
                                <Link href="/services/apply">
                                  <ShoppingCart className="w-4 h-4 mr-2" />
                                  Order to Continue
                                </Link>
                              </Button>
                           </div>
                         </div>
                      </div>
                    </div>
                  )}

                  {/* Standard Publication Grid */}
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12">
                    {groupedPublications[category.id]?.map((p: any) => (
                      <Card key={p.id} className="group border-none bg-transparent shadow-none hover:translate-y-[-4px] transition-transform duration-500">
                        <div className="relative aspect-[3/4] mb-8 overflow-hidden shadow-2xl bg-secondary/20 border border-border">
                          <img
                            src={p.imageUrl}
                            alt={p.title}
                            className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000"
                          />
                          <div className="absolute top-6 right-6">
                            <Badge className="bg-primary/80 backdrop-blur-md text-white border-white/20 text-[9px] uppercase tracking-widest px-3 py-1">Strategic Tool</Badge>
                          </div>
                        </div>
                        
                        <div className="space-y-4">
                          <h3 className="text-2xl font-headline font-bold group-hover:text-accent transition-colors leading-tight">{p.title}</h3>
                          <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-accent">{p.tagline}</p>
                          <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 italic">
                            "{p.description}"
                          </p>
                          
                          <div className="pt-6 flex gap-3 border-t border-border/50">
                            <Button variant="ghost" className="flex-1 h-10 text-[10px] font-bold uppercase tracking-widest text-primary hover:text-accent p-0 justify-start" asChild>
                              <Link href={`/publications/${p.id}`}>
                                Read More
                                <ArrowRight className="ml-2 w-3 h-3" />
                              </Link>
                            </Button>
                            <Button variant="ghost" className="flex-1 h-10 text-[10px] font-bold uppercase tracking-widest text-primary hover:text-accent p-0 justify-end" asChild>
                              <Link href="/services/apply">
                                Order to Continue
                                <ShoppingCart className="ml-2 w-3 h-3" />
                              </Link>
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>

                  {!groupedPublications[category.id] && category.id !== 'history' && category.id !== 'civic' && (
                    <div className="py-20 text-center border-2 border-dashed border-border rounded-none flex flex-col items-center justify-center">
                      <category.icon className="w-12 h-12 text-muted-foreground/20 mb-6" />
                      <p className="text-sm font-bold uppercase tracking-widest text-muted-foreground/40">
                        Currently Synchronizing {category.name} Catalog
                      </p>
                    </div>
                  )}
                </section>
              ))}
            </div>
          )}

          {/* Institutional Footer CTA */}
          <div className="mt-48 p-16 bg-primary text-primary-foreground relative overflow-hidden">
            <div className="relative z-10 grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <h3 className="text-4xl md:text-5xl font-headline font-bold mb-6">Institutional Bulk Procurement</h3>
                <p className="text-lg opacity-80 leading-relaxed mb-8">
                  GDFSD provides specialized distribution and training programs for Ministries, NGOs, and Schools. Ensure your institution is equipped with the blueprints for the "Africa We Want."
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button size="lg" className="h-14 px-10 bg-accent text-accent-foreground font-bold uppercase tracking-widest text-xs rounded-none" asChild>
                    <Link href="/services/apply">Order to Continue</Link>
                  </Button>
                  <Button size="lg" variant="outline" className="h-14 px-10 border-white/20 text-white hover:bg-white hover:text-primary transition-all font-bold uppercase tracking-widest text-xs rounded-none" asChild>
                    <Link href="/services">Read More</Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

      <Footer />
    </main>
  )
}

export default PublicationsPage

    