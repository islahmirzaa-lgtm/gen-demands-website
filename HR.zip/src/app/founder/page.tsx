
"use client"

import React, { useMemo } from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Quote, Linkedin, Mail, BookOpen, GraduationCap, MapPin, History, Shield, Scale, Loader2 } from 'lucide-react'
import Link from 'next/link'
import { useFirestore, useDoc } from '@/firebase'
import { doc } from 'firebase/firestore'

const authorBooks = [
  {
    title: "Liberia: The Spark of Africa's Freedom (1847–Today)",
    description: "A comprehensive, African-centered history that reaffirms Liberia's rightful place in continental memory. Vital lessons for achieving Agenda 2063.",
    icon: History
  },
  {
    title: "Public Sector Sustainability in Africa",
    description: "A practical index connecting governance, accountability, and development to measurable results for inclusive, ethical services.",
    icon: GraduationCap
  },
  {
    title: "From Dream to Destiny: Youth, the Architects of the Africa We Want",
    description: "A civic and leadership guide highlighting African youth as the key to continental transformation and active citizenship.",
    icon: BookOpen
  },
  {
    title: "Business English Foundations",
    description: "A series to boost professional communication and workplace skills for students and international engagement.",
    icon: Scale
  },
  {
    title: "Criminal Justice Decoded",
    description: "An accessible guide explaining criminal justice systems, procedures, and ethics for students and practitioners.",
    icon: Shield
  },
  {
    title: "Drug Detection and Suspect Tracking",
    description: "A specialized security manual covering modern investigative techniques and operational coordination in law enforcement.",
    icon: Shield
  },
  {
    title: "Maritime Defenders",
    description: "Mastering Patrol, Crime Interdiction, and Life-Saving Missions. A practical guide for safer waters and coastal protection.",
    icon: Shield
  }
]

const FounderPage = () => {
  const db = useFirestore()
  const founderDocRef = useMemo(() => doc(db, 'settings', 'founder'), [db])
  const { data: founderData, loading } = useDoc<any>(founderDocRef)

  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Hero Profile Section */}
      <div className="pt-32 pb-24 bg-background overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-12 gap-16 items-start">
            
            {/* Image Column */}
            <div className="lg:col-span-5 relative">
              <div className="relative aspect-[3/4] border border-border overflow-hidden shadow-2xl bg-secondary/20 flex items-center justify-center">
                {loading ? (
                  <Loader2 className="w-10 h-10 animate-spin text-accent" />
                ) : (
                  <img 
                    src={founderData?.imageUrl || "https://picsum.photos/seed/garrison/800/1000"} 
                    alt="Garrison B. Gaye" 
                    className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000"
                  />
                )}
                <div className="absolute inset-0 border-[20px] border-background/10 pointer-events-none" />
              </div>
              <div className="mt-8 flex items-center justify-between p-6 bg-secondary/30 border border-border">
                <div className="space-y-1">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-accent">Born</p>
                  <p className="text-sm font-bold">September 15, 1987</p>
                </div>
                <div className="space-y-1 text-right">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-accent">Hometown</p>
                  <p className="text-sm font-bold">Senlay Town, Nimba County</p>
                </div>
              </div>
            </div>

            {/* Content Column */}
            <div className="lg:col-span-7 space-y-12">
              <div>
                <Badge className="mb-4 bg-accent/20 text-accent uppercase tracking-[0.3em] px-4 py-1 rounded-none font-bold">Leadership Profile</Badge>
                <h1 className="text-5xl md:text-7xl font-headline font-bold mb-4">Garrison B. <span className="text-accent italic">Gaye.</span></h1>
                <p className="text-xl font-headline font-bold text-primary">Founder & CEO, GDFSD Inc.</p>
              </div>

              <div className="relative p-12 bg-secondary/20 border-l-4 border-accent">
                <Quote className="w-12 h-12 text-accent/20 absolute top-8 right-8" />
                <p className="text-2xl font-headline font-bold italic leading-relaxed text-primary relative z-10 text-balance">
                  "Africa's transformation will be driven by those who rise from its margins, reclaim its memory, and commit their knowledge to serving the continent."
                </p>
              </div>

              <div className="prose prose-lg prose-invert text-muted-foreground leading-relaxed space-y-8">
                <p>
                  Garrison B. Gaye is a Liberian scholar, sustainability expert, civil servant, policy thinker, and civic advocate who embodies Africa’s resilience and ambition. Raised in Twah River District, Nimba County during a period of limited opportunities due to the civil war, his worldview was shaped by hardship, community, and Liberia’s pivotal role in African history.
                </p>
                <p>
                  Facing significant barriers to education, Gaye’s journey mirrors the determination of figures like Booker T. Washington. In 2005, he enrolled at the Booker T. Washington Institute (BWI) using a borrowed name just to gain access to quality training through the DDRR Program. This first breakthrough earned him a Diploma in Secretarial Science.
                </p>
                <p>
                  Refusing to let structural obstacles define his limits, Gaye earned a Bachelor of Science in Management from AME Zion University in 2010. His commitment to global excellence led him to Nalanda University in India, where he earned an MBA in Sustainable Development and Management on a merit-based scholarship.
                </p>
                <p>
                  Today, he leads GDFSD at the intersection of history, governance, and civic education. His life and work are grounded in the belief that sustainable development requires building institutions with the same precision and care used to build a legacy.
                </p>
              </div>

              <div className="grid sm:grid-cols-2 gap-8 pt-12 border-t border-border">
                <div className="flex items-start space-x-4">
                  <GraduationCap className="w-6 h-6 text-accent shrink-0" />
                  <div>
                    <h4 className="font-bold text-[10px] uppercase tracking-widest text-accent mb-2">Education</h4>
                    <p className="text-sm font-bold">MBA Sustainable Dev. (Nalanda)</p>
                    <p className="text-xs text-muted-foreground">B.Sc Management (AME Zion)</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <MapPin className="w-6 h-6 text-accent shrink-0" />
                  <div>
                    <h4 className="font-bold text-[10px] uppercase tracking-widest text-accent mb-2">Origins</h4>
                    <p className="text-sm font-bold">Twah River District</p>
                    <p className="text-xs text-muted-foreground">Nimba County, Liberia</p>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Books Section */}
      <section className="py-24 bg-secondary/10 border-y border-border">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mb-16">
            <Badge className="mb-4 bg-primary text-primary-foreground uppercase tracking-widest px-4 py-1">Author's Legacy Suite</Badge>
            <h2 className="text-4xl md:text-5xl font-headline font-bold mb-6">Publications by <span className="text-accent">Garrison B. Gaye</span></h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              These works build a continent that remembers its past, governs wisely, and shapes its future. Covering maritime security, justice, history, and sustainability.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {authorBooks.map((book, i) => (
              <Card key={i} className="rounded-none border-border bg-background hover:border-accent transition-all group p-8 flex flex-col">
                <book.icon className="w-10 h-10 text-accent mb-6 group-hover:scale-110 transition-transform" />
                <h3 className="text-xl font-headline font-bold mb-4 line-clamp-2">{book.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed flex-1 italic">
                  "{book.description}"
                </p>
                <div className="mt-8 pt-6 border-t border-border flex justify-between items-center">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-accent">Authorized Edition</span>
                  <Link href="/publications" className="text-[10px] font-bold uppercase tracking-widest hover:underline">Details</Link>
                </div>
              </Card>
            ))}
          </div>

          <div className="mt-16 p-12 bg-primary text-primary-foreground text-center space-y-6">
            <h3 className="text-3xl font-headline font-bold">Advancing Africa's Unity & Security</h3>
            <p className="max-w-2xl mx-auto opacity-80">
              Each title stands alone, yet together they build a framework for a continent that governs with integrity and protects its people-centered societies.
            </p>
            <Button variant="outline" className="h-12 border-white/20 text-white hover:bg-accent hover:text-accent-foreground rounded-none uppercase tracking-widest text-xs font-bold" asChild>
              <Link href="/publications">Explore Full Technical Abstract</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

export default FounderPage
