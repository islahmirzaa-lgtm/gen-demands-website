
"use client"

import React from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import ImpactMap from '@/components/home/ImpactMap'
import { 
  GraduationCap, 
  Users, 
  BookOpen, 
  Building2, 
  Quote, 
  CheckCircle2,
  TrendingUp,
  Map as MapIcon
} from 'lucide-react'

const countyData = [
  { name: "Montserrado", reach: 85, schools: 142, description: "National administrative hub and highest book distribution density." },
  { name: "Nimba", reach: 72, schools: 120, description: "Major success in rural school integration of the Student Notebook." },
  { name: "Grand Bassa", reach: 60, schools: 45, description: "Institutional consultancy programs for local government suites." },
  { name: "Lofa", reach: 55, schools: 38, description: "Focus on agricultural sustainability alignment in border communities." },
  { name: "Bong", reach: 68, schools: 72, description: "High engagement with regional education officers and teachers." },
]

const testimonials = [
  {
    quote: "The Executive Sustainability Diary has transformed how we track our ministry's progress against the ARREST agenda. It's not just a book; it's a governance framework.",
    author: "Hon. J. Kollie",
    role: "Government Consultant",
    sector: "Public Administration"
  },
  {
    quote: "Seeing students in rural Nimba engage with Africa’s Agenda 2063 through their notebooks gives me hope for the next generation of Liberian leaders.",
    author: "Madam Sarah Doe",
    role: "Regional Principal",
    sector: "Education"
  },
  {
    quote: "GDFSD's consultancy helped our NGO align our sanitation projects with global SDG targets effectively. Their local insight is unmatched.",
    author: "Abraham V. Massaquoi",
    role: "NGO Director",
    sector: "Sustainability"
  }
]

const ImpactPage = () => {
  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <div className="pt-32 pb-24 bg-background relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-4 bg-accent/20 text-accent border-accent/20 uppercase tracking-widest px-4 py-1">Measuring Change</Badge>
            <h1 className="text-5xl md:text-7xl font-headline font-bold mb-6 text-balance">The Scale of <span className="text-accent">Transformation</span></h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Tracking the tangible shift from high-level policy to local action across every corner of Liberia.
            </p>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-1/2 h-full bg-accent/5 blur-[120px] -z-10" />
      </div>

      {/* Metrics Grid */}
      <section className="pb-24">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: GraduationCap, label: "Schools Reached", value: "450+", sub: "Primary & Secondary" },
              { icon: Users, label: "Public Servants", value: "12k+", sub: "Trained on Frameworks" },
              { icon: BookOpen, label: "Books Circulated", value: "50k+", sub: "Legacy Suite Copies" },
              { icon: Building2, label: "Institutions", value: "85+", sub: "Consultancy Partners" },
            ].map((stat, i) => (
              <Card key={i} className="glass-panel border-white/5 p-8 hover:border-accent/20 transition-all">
                <stat.icon className="w-10 h-10 text-accent mb-6" />
                <div className="text-4xl font-headline font-bold mb-1">{stat.value}</div>
                <div className="text-sm font-bold uppercase tracking-widest text-foreground mb-1">{stat.label}</div>
                <div className="text-xs text-muted-foreground">{stat.sub}</div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Map Integration */}
      <div className="bg-secondary/20">
        <ImpactMap />
      </div>

      {/* County Breakdown */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
              <div className="max-w-2xl">
                <h2 className="text-4xl font-headline font-bold mb-4">Regional Reach Index</h2>
                <p className="text-muted-foreground">Detailed penetration metrics across our primary operational counties.</p>
              </div>
              <div className="flex items-center space-x-2 text-accent">
                <MapIcon className="w-5 h-5" />
                <span className="text-sm font-bold uppercase tracking-widest">National Deployment</span>
              </div>
            </div>

            <div className="grid lg:grid-cols-2 gap-12">
              <div className="space-y-8">
                {countyData.map((county, i) => (
                  <div key={i} className="space-y-3">
                    <div className="flex justify-between items-end">
                      <div>
                        <span className="text-lg font-bold">{county.name}</span>
                        <span className="text-xs text-muted-foreground ml-3">{county.schools} Schools</span>
                      </div>
                      <span className="text-sm font-bold text-accent">{county.reach}%</span>
                    </div>
                    <Progress value={county.reach} className="h-2 bg-white/5" />
                    <p className="text-xs text-muted-foreground leading-relaxed">{county.description}</p>
                  </div>
                ))}
              </div>

              <Card className="glass-panel border-accent/10 p-8 flex flex-col justify-center bg-primary/10">
                <TrendingUp className="w-12 h-12 text-accent mb-6" />
                <h3 className="text-2xl font-headline font-bold mb-4">Institutional Growth Forecast</h3>
                <p className="text-muted-foreground mb-8 leading-relaxed">
                  By 2026, GDFSD aims to have distributed 100,000 legacy publications and established strategic consultancy hubs in all 15 counties of Liberia. Our focus remains on deep vertical integration within the Ministry of Education.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <CheckCircle2 className="w-5 h-5 text-accent" />
                    <span className="text-sm font-medium">Digital Portal for Partner Training (Q4 2025)</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle2 className="w-5 h-5 text-accent" />
                    <span className="text-sm font-medium">Regional Consultancy Suites in Nimba & Lofa</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-secondary/30">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-headline font-bold text-center mb-16">Voice of the <span className="text-accent">People</span></h2>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((t, i) => (
              <Card key={i} className="glass-panel border-white/5 p-8 relative">
                <Quote className="w-10 h-10 text-accent/20 absolute top-6 right-6" />
                <p className="text-lg italic mb-8 relative z-10 text-muted-foreground leading-relaxed">
                  "{t.quote}"
                </p>
                <div className="pt-6 border-t border-white/5">
                  <div className="font-bold text-foreground">{t.author}</div>
                  <div className="text-xs text-accent font-bold uppercase tracking-widest">{t.role}</div>
                  <div className="text-[10px] text-muted-foreground uppercase mt-1">{t.sector}</div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

export default ImpactPage
