
"use client"

import React from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Globe, Users, Shield, Zap, Heart, Flag } from 'lucide-react'

const aspirations = [
  { icon: Heart, title: "A Prosperous Africa", detail: "Based on inclusive growth and sustainable development." },
  { icon: Globe, title: "An Integrated Continent", detail: "Politically united and based on the ideals of Pan-Africanism." },
  { icon: Shield, title: "An Africa of Good Governance", detail: "Democracy, respect for human rights, justice and the rule of law." },
  { icon: Zap, title: "A Peaceful and Secure Africa", detail: "Ending all wars, civil conflicts, gender-based violence, and violent conflicts." },
  { icon: Flag, title: "An Africa with Strong Cultural Identity", detail: "Values and ethics rooted in Pan-Africanism." },
  { icon: Users, title: "An Africa whose Development is People-driven", detail: "Relying on the potential of African people, especially its women and youth." }
]

const Agenda2063Page = () => {
  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Hero */}
      <section className="pt-32 pb-24 bg-background relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl">
            <Badge className="mb-4 bg-primary text-primary-foreground uppercase tracking-[0.3em] px-6 py-1.5 rounded-none font-bold">Continental Masterplan</Badge>
            <h1 className="text-5xl md:text-8xl font-headline font-bold mb-8 leading-[1.1] text-primary">
              The Africa We <br /><span className="text-accent italic">Want.</span>
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed max-w-2xl border-l-2 border-accent pl-8 py-2">
              Agenda 2063 is Africa’s blueprint and master plan for transforming the continent into the global powerhouse of the future. GDFSD's "Student Notebook" is specifically designed to foster this vision in the next generation.
            </p>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-1/2 h-full bg-accent/5 blur-[120px] -z-10" />
      </section>

      {/* Seven Aspirations */}
      <section className="py-24 bg-secondary/20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center mb-20">
            <h2 className="text-4xl font-headline font-bold mb-6">The Seven <span className="text-accent">Aspirations</span></h2>
            <p className="text-muted-foreground">Mapping GDFSD educational tools to the core goals of the African Union.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {aspirations.map((a, i) => (
              <Card key={i} className="border-border rounded-none p-8 hover:bg-primary hover:text-primary-foreground transition-all group duration-500">
                <a.icon className="w-10 h-10 text-accent mb-6 group-hover:scale-110 transition-transform" />
                <h3 className="text-xl font-headline font-bold mb-4">{a.title}</h3>
                <p className="text-sm opacity-80 leading-relaxed">{a.detail}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* The Student's Blueprint */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative aspect-[4/5] bg-secondary border border-border group overflow-hidden">
               <img 
                 src="https://picsum.photos/seed/agenda2063/800/1000" 
                 alt="Students in Africa" 
                 className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000"
               />
               <div className="absolute bottom-10 left-10 bg-accent p-6 text-accent-foreground shadow-2xl">
                 <div className="text-3xl font-headline font-bold italic">500,000+</div>
                 <div className="text-[10px] font-bold uppercase tracking-widest opacity-80">Students Engaged by 2030</div>
               </div>
            </div>
            <div className="space-y-8">
              <h2 className="text-4xl md:text-5xl font-headline font-bold leading-tight">Civic Education <br />as the <span className="text-accent">Foundation.</span></h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                We believe that the realization of Agenda 2063 begins in the classroom. Our "Agenda 2063: The Student Notebook" is not just an educational tool; it is a blueprint for civic responsibility and Pan-African identity.
              </p>
              <div className="space-y-6">
                <div className="p-6 border border-border bg-secondary/10">
                  <h4 className="font-bold text-accent uppercase tracking-widest text-xs mb-2">Impact Mode</h4>
                  <p className="text-sm leading-relaxed font-medium">Standardizing the teaching of Pan-African values across Liberia's regional school districts.</p>
                </div>
                <div className="p-6 border border-border bg-secondary/10">
                  <h4 className="font-bold text-accent uppercase tracking-widest text-xs mb-2">Sustainable Development</h4>
                  <p className="text-sm leading-relaxed font-medium">Connecting student activities directly to SDG 4 (Quality Education) and AU Goal 2 (Well Educated Citizens).</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

export default Agenda2063Page
