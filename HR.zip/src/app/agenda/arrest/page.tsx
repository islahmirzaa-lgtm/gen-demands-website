
"use client"

import React from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  Sprout, 
  Truck, 
  Scale, 
  GraduationCap, 
  Droplets, 
  Palmtree,
  CheckCircle2,
  ChevronRight
} from 'lucide-react'

const arrestPillars = [
  {
    id: "agriculture",
    title: "Agriculture",
    icon: Sprout,
    description: "Prioritizing food security and value-chain development to transform Liberia into a self-reliant agrarian economy.",
    gdfsdRole: "Distributing the Student Notebook with integrated sustainable farming modules and consulting on rural youth engagement.",
    targets: ["SDG 2: Zero Hunger", "AU Goal 5: Modern Agriculture"]
  },
  {
    id: "roads",
    title: "Roads",
    icon: Truck,
    description: "Expansion of national infrastructure to bridge the gap between rural producers and urban markets.",
    gdfsdRole: "The Executive Diary provides frameworks for longitudinal maintenance planning and infrastructure legacy tracking.",
    targets: ["SDG 9: Industry & Infra", "AU Goal 10: World Class Infra"]
  },
  {
    id: "rule-of-law",
    title: "Rule of Law",
    icon: Scale,
    description: "Strengthening institutional transparency, justice, and the foundational accountability of the state.",
    gdfsdRole: "Institutional Consultancy services focused on compliance audits and standardized governance reporting.",
    targets: ["SDG 16: Peace & Justice", "AU Goal 11: Democratic Values"]
  },
  {
    id: "education",
    title: "Education",
    icon: GraduationCap,
    description: "Revitalizing the educational sector through curriculum reform and vocational excellence.",
    gdfsdRole: "Our 'Student's Blueprint' series directly integrates civic education into secondary schools nationwide.",
    targets: ["SDG 4: Quality Education", "AU Goal 2: Well Educated Citizens"]
  },
  {
    id: "sanitation",
    title: "Sanitation",
    icon: Droplets,
    description: "Improving public health through urban waste management and sustainable water systems.",
    gdfsdRole: "Advocacy planning and impact monitoring for regional sanitation initiatives.",
    targets: ["SDG 6: Clean Water", "AU Goal 7: Healthy Citizens"]
  },
  {
    id: "tourism",
    title: "Tourism",
    icon: Palmtree,
    description: "Harnessing Liberia's natural beauty and historical heritage to drive economic growth.",
    gdfsdRole: "'The Spark of Africa's Freedom' publication serves as a primary resource for heritage-based tourism development.",
    targets: ["SDG 8: Decent Work", "AU Goal 19: Cultural Identity"]
  }
]

const ArrestPage = () => {
  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Header */}
      <div className="pt-32 pb-24 bg-primary text-primary-foreground relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10 text-center">
          <Badge className="mb-4 bg-accent text-accent-foreground uppercase tracking-[0.3em] px-6 py-1.5 rounded-none font-bold">National Priority</Badge>
          <h1 className="text-5xl md:text-7xl font-headline font-bold mb-6 text-balance">The <span className="text-accent italic">ARREST</span> Agenda</h1>
          <p className="text-xl opacity-80 max-w-3xl mx-auto leading-relaxed">
            Liberia's strategic roadmap for national recovery and sustainable growth. GDFSD serves as the primary implementation bridge for these six developmental pillars.
          </p>
        </div>
        <div className="absolute inset-0 bg-accent/5 -z-0" />
      </div>

      {/* Pillars Grid */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {arrestPillars.map((pillar) => (
              <Card key={pillar.id} className="border-border rounded-none group hover:border-accent transition-all duration-500">
                <CardHeader className="pb-4">
                  <div className="w-16 h-16 bg-secondary flex items-center justify-center mb-6 group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
                    <pillar.icon className="w-8 h-8" />
                  </div>
                  <CardTitle className="text-3xl font-headline font-bold">{pillar.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <p className="text-muted-foreground leading-relaxed">
                    {pillar.description}
                  </p>
                  
                  <div className="pt-6 border-t border-border">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-accent mb-3 block">GDFSD Strategic Role</span>
                    <p className="text-sm font-medium leading-relaxed italic">
                      "{pillar.gdfsdRole}"
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2 pt-4">
                    {pillar.targets.map((target, idx) => (
                      <Badge key={idx} variant="secondary" className="text-[9px] uppercase tracking-tighter rounded-none">
                        {target}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Policy Bridge Section */}
      <section className="py-24 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2">
              <h2 className="text-4xl font-headline font-bold mb-6">Vertical <span className="text-accent">Integration</span> of Policy</h2>
              <p className="text-muted-foreground mb-8 leading-relaxed">
                The GDFSD methodology ensures that national strategy doesn't remain in ministerial documents but translates into classroom curriculum and institutional operations. We specialize in the horizontal connection across these pillars.
              </p>
              <div className="space-y-4">
                {[
                  "Standardizing reporting across multiple ministries",
                  "Aligning school curriculum with national labor needs",
                  "Mapping legacy milestones for executive leadership",
                  "Tracking real-time impact in rural border counties"
                ].map((item, i) => (
                  <div key={i} className="flex items-center space-x-3">
                    <CheckCircle2 className="w-5 h-5 text-accent" />
                    <span className="text-sm font-bold uppercase tracking-widest text-primary">{item}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="lg:w-1/2 p-12 bg-primary text-primary-foreground border-l-8 border-accent">
              <h3 className="text-2xl font-headline font-bold mb-4">Request Alignment Brief</h3>
              <p className="text-sm opacity-80 mb-8 leading-relaxed">
                Does your institution or bureau need a specialized mapping of your goals to the ARREST Agenda? Our consultants provide detailed alignment audits for public and private sector leaders.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="h-12 px-8 bg-accent text-accent-foreground font-bold text-xs uppercase tracking-[0.2em]">Contact Govt Relations</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

export default ArrestPage
