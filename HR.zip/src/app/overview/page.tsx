
"use client"

import React from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Book, 
  Layers, 
  Cpu, 
  Palette, 
  Globe, 
  FileText, 
  Layout, 
  Database, 
  Zap,
  CheckCircle2,
  Component
} from 'lucide-react'

const OverviewPage = () => {
  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      <div className="pt-32 pb-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto mb-16 text-center">
            <Badge className="mb-4 bg-accent/20 text-accent border-accent/20 uppercase tracking-widest px-4 py-1">Master Document</Badge>
            <h1 className="text-5xl md:text-7xl font-headline font-bold mb-6">System Architecture & Content Overview</h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              This document provides a complete technical and strategic blueprint for the Vantage GDFSD digital hub.
            </p>
          </div>

          <Tabs defaultValue="design" className="max-w-5xl mx-auto">
            <TabsList className="grid grid-cols-2 md:grid-cols-4 h-auto p-1 bg-secondary/50 rounded-xl mb-12">
              <TabsTrigger value="design" className="py-3 rounded-lg data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
                <Palette className="w-4 h-4 mr-2" />
                Design
              </TabsTrigger>
              <TabsTrigger value="structure" className="py-3 rounded-lg data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
                <Layers className="w-4 h-4 mr-2" />
                Structure
              </TabsTrigger>
              <TabsTrigger value="content" className="py-3 rounded-lg data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
                <Book className="w-4 h-4 mr-2" />
                Content
              </TabsTrigger>
              <TabsTrigger value="ai" className="py-3 rounded-lg data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
                <Cpu className="w-4 h-4 mr-2" />
                AI Strategy
              </TabsTrigger>
            </TabsList>

            <TabsContent value="design" className="space-y-8 animate-in fade-in duration-500">
              <div className="grid md:grid-cols-2 gap-8">
                <Card className="glass-panel border-white/5">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Palette className="w-5 h-5 text-accent" />
                      <span>Visual Identity</span>
                    </CardTitle>
                    <CardDescription>Aesthetic principles and color systems.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">The system utilizes a "Command Center" aesthetic, designed to evoke institutional trust and forward-looking innovation.</p>
                    <div className="flex items-center space-x-4 p-4 rounded-lg bg-white/5">
                      <div className="w-10 h-10 rounded bg-[#1e293b] border border-white/10" />
                      <div>
                        <div className="text-xs font-bold">Primary: Navy Blue</div>
                        <div className="text-[10px] text-muted-foreground uppercase">hsl(222, 46%, 31%)</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 p-4 rounded-lg bg-white/5">
                      <div className="w-10 h-10 rounded bg-[#4ec5e6] border border-white/10" />
                      <div>
                        <div className="text-xs font-bold">Accent: Cyan Spark</div>
                        <div className="text-[10px] text-muted-foreground uppercase">hsl(193, 76%, 59%)</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="glass-panel border-white/5">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Layout className="w-5 h-5 text-accent" />
                      <span>Typography & Layout</span>
                    </CardTitle>
                    <CardDescription>Font choices and spatial design.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="font-headline text-2xl">Playfair Display</div>
                      <p className="text-xs text-muted-foreground">Used for headlines to convey a prestigious "Legacy" feel and authority.</p>
                    </div>
                    <div className="space-y-2">
                      <div className="font-body text-lg">PT Sans</div>
                      <p className="text-xs text-muted-foreground">Used for body text for clarity, accessibility, and modern professionalism.</p>
                    </div>
                    <div className="pt-4 border-t border-white/5">
                      <Badge variant="outline" className="text-[10px] uppercase">Glassmorphism</Badge>
                      <Badge variant="outline" className="ml-2 text-[10px] uppercase">Dark Default</Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="structure" className="space-y-8 animate-in fade-in duration-500">
              <Card className="glass-panel border-white/5">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Layers className="w-5 h-5 text-accent" />
                    <span>Technical Stack & Architecture</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="p-6 rounded-2xl bg-white/5 border border-white/5">
                      <Zap className="w-6 h-6 text-accent mb-4" />
                      <h4 className="font-bold mb-2">Framework</h4>
                      <p className="text-xs text-muted-foreground">Next.js 15 with App Router for server-side optimization and routing.</p>
                    </div>
                    <div className="p-6 rounded-2xl bg-white/5 border border-white/5">
                      <Database className="w-6 h-6 text-accent mb-4" />
                      <h4 className="font-bold mb-2">Persistence</h4>
                      <p className="text-xs text-muted-foreground">Firebase Firestore & Auth (Planned) for secure institutional data.</p>
                    </div>
                    <div className="p-6 rounded-2xl bg-white/5 border border-white/5">
                      <Component className="w-6 h-6 text-accent mb-4" />
                      <h4 className="font-bold mb-2">UI Library</h4>
                      <p className="text-xs text-muted-foreground">ShadCN UI components built on Tailwind CSS and Radix Primitives.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="content" className="space-y-8 animate-in fade-in duration-500">
              <Card className="glass-panel border-white/5">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Book className="w-5 h-5 text-accent" />
                    <span>Legacy Publication Suite Content</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex items-start space-x-4">
                      <div className="mt-1 w-2 h-2 rounded-full bg-accent" />
                      <div>
                        <h4 className="font-bold text-lg">Executive Sustainability Diary</h4>
                        <p className="text-sm text-muted-foreground">"The Leader's Legacy." Focused on institutional performance tracking and legacy building for CEOs.</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-4">
                      <div className="mt-1 w-2 h-2 rounded-full bg-accent" />
                      <div>
                        <h4 className="font-bold text-lg">Africa’s Agenda 2063: The Student Notebook</h4>
                        <p className="text-sm text-muted-foreground">"The Student's Blueprint." Integrating civic education and Pan-Africanism into the Liberian classroom.</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-4">
                      <div className="mt-1 w-2 h-2 rounded-full bg-accent" />
                      <div>
                        <h4 className="font-bold text-lg">Liberia: The Spark of Africa’s Freedom</h4>
                        <p className="text-sm text-muted-foreground">"The Nation's Memory." A historical reclamation guide for researchers and youth.</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-4">
                      <div className="mt-1 w-2 h-2 rounded-full bg-accent" />
                      <div>
                        <h4 className="font-bold text-lg">From Dream to Destiny</h4>
                        <p className="text-sm text-muted-foreground">"The Architect's Guide." Tools for strategic visioning and transitioning from concept to execution.</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="ai" className="space-y-8 animate-in fade-in duration-500">
              <Card className="glass-panel border-white/5">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Cpu className="w-5 h-5 text-accent" />
                    <span>Genkit Policy Intelligence</span>
                  </CardTitle>
                  <CardDescription>How AI powers the consultancy experience.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="p-6 rounded-2xl bg-primary/20 border border-white/5">
                    <div className="flex items-center space-x-4 mb-4">
                      <Globe className="w-6 h-6 text-accent" />
                      <h4 className="font-bold">Framework Alignment Reports</h4>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Using Google Gemini 2.5 Flash via Genkit, the system generates real-time reports aligning GDFSD products with:
                    </p>
                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <li className="flex items-center text-xs space-x-2">
                        <CheckCircle2 className="w-3 h-3 text-accent" />
                        <span>Liberia's ARREST Agenda</span>
                      </li>
                      <li className="flex items-center text-xs space-x-2">
                        <CheckCircle2 className="w-3 h-3 text-accent" />
                        <span>AU Agenda 2063</span>
                      </li>
                      <li className="flex items-center text-xs space-x-2">
                        <CheckCircle2 className="w-3 h-3 text-accent" />
                        <span>UN SDGs 2030</span>
                      </li>
                      <li className="flex items-center text-xs space-x-2">
                        <CheckCircle2 className="w-3 h-3 text-accent" />
                        <span>ECOWAS Vision 2050</span>
                      </li>
                    </ul>
                  </div>

                  <div className="flex items-center justify-center p-8 border-2 border-dashed border-white/10 rounded-2xl">
                    <div className="text-center">
                      <FileText className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
                      <p className="text-sm font-medium">Action Plans for Cultural Integration</p>
                      <p className="text-xs text-muted-foreground mt-1">AI-driven mapping of holiday significance to developmental milestones.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <Footer />
    </main>
  )
}

export default OverviewPage
