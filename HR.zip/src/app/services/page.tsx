
"use client"

import React from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import ConsultancyCalculator from '@/components/home/ConsultancyCalculator'
import { 
  Briefcase, 
  ShieldCheck, 
  Target, 
  LineChart, 
  Globe, 
  Users, 
  ArrowRight,
  CheckCircle2,
  Cpu,
  Landmark,
  BookOpen,
  GraduationCap,
  Scale,
  Search,
  Settings,
  Shield,
  FileText
} from 'lucide-react'

const servicePillars = [
  {
    title: "Framework Alignment Consultancy",
    description: "Meticulous mapping of institutional objectives to Liberia's ARREST Agenda, AU Agenda 2063, and UN SDGs.",
    icon: Globe,
    features: ["Gap Analysis Reports", "Strategic Alignment Roadmaps", "Framework Compliance Audits"]
  },
  {
    title: "Institutional Capacity Building",
    description: "High-level training for executives and public servants focused on sustainability leadership and legacy tracking.",
    icon: Landmark,
    features: ["Executive Leadership Workshops", "Legacy Planning Sessions", "Sustainability Reporting Systems"]
  },
  {
    title: "Civic Education Integration",
    description: "Designing and embedding civic responsibility modules into educational curricula for private and public institutions.",
    icon: GraduationCap,
    features: ["Curriculum Development", "Teacher Training Programs", "Civic Engagement Frameworks"]
  },
  {
    title: "Impact Monitoring & Evaluation",
    description: "Data-driven tracking of developmental milestones to ensure institutional efforts yield tangible social impact.",
    icon: LineChart,
    features: ["Data Collection Design", "Progress Dashboarding", "Stakeholder Impact Reports"]
  }
]

const analyticalWorkflow = [
  { 
    title: "Diagnostic Intelligence", 
    icon: Search, 
    detail: "Our analysts perform a deep-dive audit of your institution's current policy documents and operational KPIs against national standards." 
  },
  { 
    title: "Framework Synchronization", 
    icon: Settings, 
    detail: "We use proprietary GDFSD mapping tools to identify direct touchpoints between your goals and the ARREST or Agenda 2063 pillars." 
  },
  { 
    title: "Tactical Deployment", 
    icon: Target, 
    detail: "Lead consultants embed strategic milestones into your internal workflows, ensuring that policy isn't just documented, but executed." 
  },
  { 
    title: "Legacy Verification", 
    icon: Shield, 
    detail: "Continuous monitoring protocols are established to verify that impact reaches the ground level, suitable for donor and government reporting." 
  }
]

const leadConsultants = [
  {
    name: "Strategic Lead: Governance",
    role: "Policy Alignment Architect",
    specialty: "ARREST Agenda & Rule of Law",
    bio: "Specializes in the vertical integration of national legal frameworks within ministerial operations."
  },
  {
    name: "Strategic Lead: Education",
    role: "Curriculum Integration Expert",
    specialty: "Civic Education & Agenda 2063",
    bio: "Focuses on the standardization of Pan-African values within secondary and primary educational tiers."
  },
  {
    name: "Strategic Lead: Monitoring",
    role: "Impact Evaluation Specialist",
    specialty: "SDG 2030 Data Tracking",
    bio: "Develops the data-driven dashboards used to track longitudinal institutional progress and legacy."
  }
]

const ServicesPage = () => {
  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <div className="pt-32 pb-24 bg-primary text-primary-foreground relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl">
            <Badge className="mb-4 bg-accent text-accent-foreground uppercase tracking-[0.3em] px-6 py-1.5 rounded-none font-bold">The Consultancy Suite</Badge>
            <h1 className="text-5xl md:text-8xl font-headline font-bold mb-8 leading-tight">Expertise Driven by <br /><span className="text-accent italic">Strategic Precision.</span></h1>
            <p className="text-xl opacity-80 leading-relaxed max-w-2xl border-l border-white/20 pl-8 py-2">
              Beyond standard advice, GDFSD provides the technical architecture needed to bridge the gap between continental vision and institutional execution.
            </p>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-1/2 h-full bg-accent/5 blur-[150px] -z-0" />
      </div>

      {/* Internal Analytical Workflow */}
      <section className="py-24 bg-background border-b border-border">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mb-16">
            <h2 className="text-4xl font-headline font-bold mb-6">The Expert <span className="text-accent">Workflow</span></h2>
            <p className="text-muted-foreground text-lg">
              Understanding the internal mechanics of how our consultants transform your institutional strategy.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {analyticalWorkflow.map((flow, i) => (
              <div key={i} className="space-y-6 group">
                <div className="w-16 h-16 bg-secondary flex items-center justify-center group-hover:bg-accent group-hover:text-accent-foreground transition-all duration-500">
                  <flow.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-headline font-bold">{flow.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {flow.detail}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Strategic Lead Consultants */}
      <section className="py-24 bg-secondary/10">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center mb-20">
            <h2 className="text-4xl font-headline font-bold mb-6">Our Lead <span className="text-accent">Consultants</span></h2>
            <p className="text-muted-foreground">The specialized minds responsible for GDFSD's high-level framework synchronization.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {leadConsultants.map((consultant, i) => (
              <Card key={i} className="border-border rounded-none p-10 hover:border-accent transition-all duration-500 group">
                <div className="space-y-6">
                  <div className="w-12 h-1 bg-accent" />
                  <h3 className="text-2xl font-headline font-bold">{consultant.name}</h3>
                  <div className="space-y-1">
                    <p className="text-xs font-bold uppercase tracking-widest text-accent">{consultant.role}</p>
                    <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">{consultant.specialty}</p>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed italic">
                    "{consultant.bio}"
                  </p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* AI Alignment Engine Integration */}
      <div className="bg-background">
        <ConsultancyCalculator />
      </div>

      {/* Service Pillars Grid */}
      <section className="py-24 bg-secondary/30 border-t border-border">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mb-16">
            <h2 className="text-4xl font-headline font-bold mb-4 text-balance">Consultancy <span className="text-accent">Pillars</span></h2>
            <p className="text-muted-foreground">Four foundational areas where GDFSD provides world-class institutional support.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {servicePillars.map((service, i) => (
              <Card key={i} className="border-border rounded-none bg-background hover:bg-primary hover:text-primary-foreground transition-all duration-500 flex flex-col group">
                <CardHeader>
                  <div className="w-12 h-12 rounded-none bg-accent/10 flex items-center justify-center mb-4 group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
                    <service.icon className="w-6 h-6 text-accent group-hover:text-inherit" />
                  </div>
                  <CardTitle className="text-xl font-headline">{service.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1 space-y-6">
                  <p className="text-sm opacity-80 leading-relaxed">
                    {service.description}
                  </p>
                  <ul className="space-y-2">
                    {service.features.map((feat, fi) => (
                      <li key={fi} className="flex items-center space-x-2 text-[10px] font-bold uppercase tracking-widest text-accent">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-primary text-primary-foreground relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h2 className="text-4xl md:text-6xl font-headline font-bold">Synchronize Your <br /><span className="text-accent italic">Institutional Legacy.</span></h2>
            <p className="text-xl opacity-80 max-w-2xl mx-auto">
              Partner with the consultants who understand both the international framework and the local reality.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
              <Button size="lg" className="h-16 px-10 rounded-none bg-accent text-accent-foreground font-bold text-xs uppercase tracking-[0.2em]" asChild>
                <Link href="/services/apply">Apply for Strategic Brief</Link>
              </Button>
              <Button size="lg" variant="outline" className="h-16 px-10 rounded-none border-white/20 text-white hover:bg-white hover:text-primary transition-all text-xs font-bold uppercase tracking-[0.2em]">View Technical Abstract</Button>
            </div>
          </div>
        </div>
        <div className="absolute inset-0 bg-accent/5 -z-0" />
      </section>

      <Footer />
    </main>
  )
}

export default ServicesPage
