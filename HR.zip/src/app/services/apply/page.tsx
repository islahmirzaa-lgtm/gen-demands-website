
"use client"

import React, { useState } from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import { useFirestore } from '@/firebase'
import { collection, addDoc, serverTimestamp } from 'firebase/firestore'
import { useToast } from '@/hooks/use-toast'
import { Loader2, Send, CheckCircle2, ShieldCheck, MessageCircle } from 'lucide-react'
import { errorEmitter } from '@/firebase/error-emitter'
import { FirestorePermissionError } from '@/firebase/errors'

const ConsultancyApplyPage = () => {
  const db = useFirestore()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const [formData, setFormData] = useState({
    institutionName: '',
    contactName: '',
    email: '',
    phone: '',
    sector: '',
    interest: '',
    message: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.institutionName || !formData.email || !formData.sector) {
      toast({ variant: "destructive", title: "Missing Fields", description: "Please fill out all required institutional details." })
      return
    }

    setIsSubmitting(true)
    const requestsRef = collection(db, 'consultancyRequests')

    // Construct WhatsApp Message
    const whatsappMsg = `*GDFSD Strategic Briefing Request*
---
*Institution:* ${formData.institutionName}
*Contact:* ${formData.contactName}
*Sector:* ${formData.sector}
*Interest:* ${formData.interest}
*Email:* ${formData.email}
*Phone:* ${formData.phone}
---
*Details:* ${formData.message}`;

    const encodedMsg = encodeURIComponent(whatsappMsg);
    const whatsappUrl = `https://wa.me/231770471560?text=${encodedMsg}`;

    addDoc(requestsRef, {
      ...formData,
      status: 'Pending',
      createdAt: serverTimestamp()
    }).then(() => {
      setSubmitted(true)
      toast({ title: "Request Submitted", description: "Your alignment brief request has been recorded. Opening WhatsApp..." })
      
      // Redirect to WhatsApp in a new tab
      window.open(whatsappUrl, '_blank');
    }).catch(async (err) => {
      const permissionError = new FirestorePermissionError({
        path: requestsRef.path,
        operation: 'create',
        requestResourceData: formData,
      })
      errorEmitter.emit('permission-error', permissionError)
    }).finally(() => {
      setIsSubmitting(false)
    })
  }

  if (submitted) {
    return (
      <main className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center p-4">
          <div className="max-w-md w-full text-center space-y-8 animate-in fade-in zoom-in duration-500">
            <div className="w-20 h-20 bg-accent/10 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10 text-accent" />
            </div>
            <h1 className="text-4xl font-headline font-bold">Request <span className="text-accent">Received.</span></h1>
            <p className="text-muted-foreground leading-relaxed">
              Your application for institutional alignment has been recorded and a WhatsApp message has been initiated. A representative from GDFSD Government Relations will review your brief and contact you shortly.
            </p>
            <Button asChild className="w-full bg-primary h-14 font-bold uppercase tracking-widest text-xs">
              <a href="/services">Return to Services</a>
            </Button>
          </div>
        </div>
        <Footer />
      </main>
    )
  }

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <div className="pt-32 pb-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row gap-16">
              
              {/* Left Column: Context */}
              <div className="md:w-1/3 space-y-8">
                <Badge className="bg-accent/20 text-accent uppercase tracking-widest px-4 py-1">Institutional Portal</Badge>
                <h1 className="text-4xl font-headline font-bold">Apply for <br /><span className="text-accent italic">Strategic Brief.</span></h1>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  GDFSD provides high-level consultancy for Ministries, NGOs, and the Private Sector. This application starts the process of vertical integration and alerts our strategic team via WhatsApp.
                </p>
                <div className="space-y-4 pt-8">
                  <div className="flex items-center space-x-3 text-xs font-bold uppercase tracking-widest opacity-60">
                    <ShieldCheck className="w-4 h-4 text-accent" />
                    <span>Confidential Handling</span>
                  </div>
                  <div className="flex items-center space-x-3 text-xs font-bold uppercase tracking-widest opacity-60">
                    <ShieldCheck className="w-4 h-4 text-accent" />
                    <span>WhatsApp Direct Integration</span>
                  </div>
                </div>
              </div>

              {/* Right Column: Form */}
              <div className="md:w-2/3">
                <Card className="glass-panel border-white/5 shadow-2xl">
                  <CardHeader className="bg-primary/5">
                    <CardTitle className="font-headline">Request Specifications</CardTitle>
                    <CardDescription>Submitting this form will record your data and open a direct line to our lead consultants.</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-8">
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid sm:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label className="text-[10px] uppercase tracking-widest font-bold">Institution Name *</Label>
                          <Input required value={formData.institutionName} onChange={e => setFormData(p => ({ ...p, institutionName: e.target.value }))} className="bg-background/50" placeholder="e.g. Ministry of Education" />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-[10px] uppercase tracking-widest font-bold">Contact Person *</Label>
                          <Input required value={formData.contactName} onChange={e => setFormData(p => ({ ...p, contactName: e.target.value }))} className="bg-background/50" placeholder="Full Name & Title" />
                        </div>
                      </div>

                      <div className="grid sm:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label className="text-[10px] uppercase tracking-widest font-bold">Official Email *</Label>
                          <Input required type="email" value={formData.email} onChange={e => setFormData(p => ({ ...p, email: e.target.value }))} className="bg-background/50" placeholder="institutional-email@org.lr" />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-[10px] uppercase tracking-widest font-bold">Phone Number</Label>
                          <Input value={formData.phone} onChange={e => setFormData(p => ({ ...p, phone: e.target.value }))} className="bg-background/50" placeholder="+231..." />
                        </div>
                      </div>

                      <div className="grid sm:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label className="text-[10px] uppercase tracking-widest font-bold">Institutional Sector *</Label>
                          <Select onValueChange={val => setFormData(p => ({ ...p, sector: val }))}>
                            <SelectTrigger className="bg-background/50">
                              <SelectValue placeholder="Select Sector" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Education">Education / Schools</SelectItem>
                              <SelectItem value="Finance">Finance / Banking</SelectItem>
                              <SelectItem value="Agriculture">Agriculture / Rural Dev</SelectItem>
                              <SelectItem value="Governance">Government / Bureau</SelectItem>
                              <SelectItem value="Other">Other Institutional</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-[10px] uppercase tracking-widest font-bold">Primary Interest *</Label>
                          <Select onValueChange={val => setFormData(p => ({ ...p, interest: val }))}>
                            <SelectTrigger className="bg-background/50">
                              <SelectValue placeholder="Select Service" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Framework Alignment">Framework Alignment</SelectItem>
                              <SelectItem value="Capacity Building">Institutional Training</SelectItem>
                              <SelectItem value="Curriculum Integration">Civic Curriculum</SelectItem>
                              <SelectItem value="Impact Monitoring">Impact Monitoring</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label className="text-[10px] uppercase tracking-widest font-bold">Strategic Briefing Details</Label>
                        <Textarea value={formData.message} onChange={e => setFormData(p => ({ ...p, message: e.target.value }))} className="bg-background/50 min-h-[120px]" placeholder="Outline your specific objectives or institutional hurdles..." />
                      </div>

                      <Button type="submit" disabled={isSubmitting} className="w-full h-14 bg-accent text-accent-foreground font-bold uppercase tracking-[0.2em] text-xs">
                        {isSubmitting ? (
                          <Loader2 className="w-4 h-4 animate-spin mr-2" />
                        ) : (
                          <MessageCircle className="w-4 h-4 mr-2" />
                        )}
                        Submit & Launch WhatsApp Briefing
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>

            </div>
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}

export default ConsultancyApplyPage
