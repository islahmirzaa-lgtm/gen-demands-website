import type {Metadata} from 'next';
import './globals.css';
import { Toaster } from "@/components/ui/toaster"
import { FirebaseClientProvider } from '@/firebase';
import { ThemeProvider } from '@/components/layout/ThemeProvider';
import Script from 'next/script';
import { SYSTEM_NAME } from '@/lib/constants';
import { ChatBox } from '@/components/layout/ChatBox';

export const metadata: Metadata = {
  title: `${SYSTEM_NAME} | Institutional Strategy Hub`,
  description: 'Generational Demands Inc. - Strategic consultancy bridging international policy and national implementation.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@400;700&family=Inter:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased min-h-screen selection:bg-accent/30 overflow-x-hidden">
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          <FirebaseClientProvider>
            <div className="relative z-0">
              {/* Presidential structural background layers */}
              <div className="fixed inset-0 strategic-grid -z-10 opacity-30 pointer-events-none" />
              <div className="fixed inset-0 bg-gradient-to-tr from-accent/[0.02] via-transparent to-primary/[0.02] -z-10 pointer-events-none" />
              
              {children}
              <ChatBox />
              <Toaster />
            </div>
          </FirebaseClientProvider>
        </ThemeProvider>
        
        {/* Google Translate Integration Bridge - Global System Impact */}
        <Script
          src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"
          strategy="afterInteractive"
        />
        <Script id="google-translate-init" strategy="afterInteractive">
          {`
            function googleTranslateElementInit() {
              new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,fr,es,de,zh-CN,ar,pt',
                layout: google.translate.TranslateElement.InlineLayout.SIMPLE,
                autoDisplay: false
              }, 'google_translate_element');
            }
          `}
        </Script>
      </body>
    </html>
  );
}
