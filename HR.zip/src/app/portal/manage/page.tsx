"use client"

import React, { useState, useCallback, useEffect, useMemo } from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useFirestore, useDoc, useCollection } from '@/firebase'
import { collection, addDoc, serverTimestamp, doc, setDoc, deleteDoc, query, orderBy } from 'firebase/firestore'
import { errorEmitter } from '@/firebase/error-emitter'
import { FirestorePermissionError } from '@/firebase/errors'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import { Loader2, Upload, Plus, Trash2, User, BookOpen, Layers, Globe, CheckCircle2, ShieldCheck, Lock, ShieldAlert, Cpu, Terminal } from 'lucide-react'

const ManagePortal = () => {
  const db = useFirestore()
  const { toast } = useToast()
  
  // Access Gate State
  const [accessCode, setAccessCode] = useState('')
  const [isAuthorized, setIsAuthorized] = useState(false)
  const [authError, setAuthError] = useState(false)

  // Portal Management State
  const [isUploading, setIsUploading] = useState(false)
  const [isSavingFounder, setIsSavingFounder] = useState(false)
  
  // Publication Form State
  const [formData, setFormData] = useState({
    title: '',
    tagline: '',
    description: '',
    category: 'Governance',
    imageUrl: '',
    features: [''],
    alignment: [{ framework: '', pillar: '', detail: '' }]
  })

  // Publications Collection
  const publicationsQuery = useMemo(() => {
    if (!db) return null
    return query(collection(db, 'publications'), orderBy('createdAt', 'desc'))
  }, [db])
  const { data: publications, loading: publicationsLoading } = useCollection<any>(publicationsQuery)

  // Founder Profile State
  const [founderImageUrl, setFounderImageUrl] = useState('')
  const founderDocRef = useMemo(() => doc(db, 'settings', 'founder'), [db])
  const { data: founderData, loading: founderLoading } = useDoc<any>(founderDocRef)

  useEffect(() => {
    if (founderData?.imageUrl) {
      setFounderImageUrl(founderData.imageUrl)
    }
  }, [founderData])

  const handleAccessSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (accessCode === 'Garris123') {
      setIsAuthorized(true)
      setAuthError(false)
      toast({ title: "Authorization Confirmed", description: "Strategic repository access granted." })
    } else {
      setAuthError(true)
      toast({ variant: "destructive", title: "Access Denied", description: "Invalid institutional authorization code." })
    }
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, target: 'publication' | 'founder') => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        if (target === 'publication') {
          setFormData(prev => ({ ...prev, imageUrl: reader.result as string }))
        } else {
          setFounderImageUrl(reader.result as string)
        }
      }
      reader.readAsDataURL(file)
    }
  }

  // Publication Logic
  const addFeature = () => setFormData(p => ({ ...p, features: [...p.features, ''] }))
  const updateFeature = (index: number, val: string) => {
    const next = [...formData.features]
    next[index] = val
    setFormData(p => ({ ...p, features: next }))
  }
  const removeFeature = (index: number) => setFormData(p => ({ ...p, features: formData.features.filter((_, i) => i !== index) }))

  const addAlignment = () => setFormData(p => ({ ...p, alignment: [...p.alignment, { framework: '', pillar: '', detail: '' }] }))
  const updateAlignment = (index: number, key: string, val: string) => {
    const next = [...formData.alignment]
    next[index] = { ...next[index], [key]: val }
    setFormData(p => ({ ...p, alignment: next }))
  }
  const removeAlignment = (index: number) => setFormData(p => ({ ...p, alignment: formData.alignment.filter((_, i) => i !== index) }))

  const handleSavePublication = async () => {
    if (!formData.title || !formData.imageUrl) {
      toast({ variant: "destructive", title: "Missing Information", description: "Title and Image are required." })
      return
    }

    setIsUploading(true)
    const publicationsRef = collection(db, 'publications')

    addDoc(publicationsRef, {
      ...formData,
      features: formData.features.filter(f => f.trim() !== ''),
      alignment: formData.alignment.filter(a => a.framework.trim() !== ''),
      createdAt: serverTimestamp()
    }).then(() => {
      toast({ title: "Publication Added", description: `${formData.title} has been saved to the library.` })
      setFormData({
        title: '',
        tagline: '',
        description: '',
        category: 'Governance',
        imageUrl: '',
        features: [''],
        alignment: [{ framework: '', pillar: '', detail: '' }]
      })
    }).catch(async (err) => {
      const permissionError = new FirestorePermissionError({
        path: publicationsRef.path,
        operation: 'create',
        requestResourceData: formData,
      })
      errorEmitter.emit('permission-error', permissionError)
    }).finally(() => {
      setIsUploading(false)
    })
  }

  const handleDeletePublication = (id: string) => {
    const ref = doc(db, 'publications', id)
    deleteDoc(ref).then(() => {
      toast({ title: "Record Deleted", description: "The publication has been removed from the library." })
    }).catch(async (err) => {
      const permissionError = new FirestorePermissionError({
        path: ref.path,
        operation: 'delete',
      })
      errorEmitter.emit('permission-error', permissionError)
    })
  }

  const handleSaveFounder = async () => {
    if (!founderImageUrl) {
      toast({ variant: "destructive", title: "Missing Information", description: "Please upload an image for the founder profile." })
      return
    }

    setIsSavingFounder(true)
    setDoc(founderDocRef, {
      imageUrl: founderImageUrl,
      updatedAt: serverTimestamp()
    }, { merge: true })
      .then(() => {
        toast({ title: "Founder Profile Updated", description: "The founder's profile image has been updated successfully." })
      })
      .catch(async (err) => {
        const permissionError = new FirestorePermissionError({
          path: founderDocRef.path,
          operation: 'update',
          requestResourceData: { imageUrl: founderImageUrl },
        })
        errorEmitter.emit('permission-error', permissionError)
      })
      .finally(() => {
        setIsSavingFounder(false)
      })
  }

  if (!isAuthorized) {
    return (
      <main className="min-h-screen flex flex-col items-center justify-center bg-background p-4 relative overflow-hidden strategic-grid">
        <Navbar />
        
        <div className="max-w-xl w-full relative z-10 strategic-reveal px-4">
          <Card className="rounded-none border-2 border-accent/30 shadow-2xl bg-background/95 backdrop-blur-xl overflow-hidden">
            <CardHeader className="bg-primary text-primary-foreground p-6 md:p-12 text-center space-y-4 md:space-y-6 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-accent" />
              <div className="w-16 h-16 md:w-20 md:h-20 bg-accent rounded-none mx-auto flex items-center justify-center shadow-2xl shadow-accent/40 animate-pulse">
                <Terminal className="w-8 h-8 md:w-10 md:h-10 text-accent-foreground" />
              </div>
              <div className="space-y-2">
                <CardTitle className="text-2xl md:text-4xl font-headline font-bold uppercase tracking-tight">Institutional Gateway</CardTitle>
                <CardDescription className="text-accent text-[9px] md:text-[10px] font-bold uppercase tracking-[0.4em] md:tracking-[0.5em] animate-pulse">Restricted Strategic Repository</CardDescription>
              </div>
            </CardHeader>
            <CardContent className="p-6 md:p-12 space-y-6 md:space-y-10">
              <div className="p-4 md:p-6 bg-secondary/20 border border-border/50 font-mono text-[9px] md:text-[10px] text-muted-foreground leading-relaxed">
                <p>{'>'} INIT SYSTEM_AUTH_V2.5.9</p>
                <p>{'>'} PINGING GDFSD-SECURE-SERVER...</p>
                <p>{'>'} WAITING FOR INSTITUTIONAL CLEARANCE...</p>
              </div>
              
              <form onSubmit={handleAccessSubmit} className="space-y-6 md:space-y-8">
                <div className="space-y-4">
                  <Label className="text-[10px] md:text-[11px] font-bold uppercase tracking-[0.3em] md:tracking-[0.4em] text-accent opacity-80">Authorization Protocol</Label>
                  <Input 
                    type="password"
                    value={accessCode}
                    onChange={(e) => setAccessCode(e.target.value)}
                    placeholder="ENTER CODE"
                    className={cn(
                      "rounded-none h-16 md:h-20 bg-secondary/10 border-2 border-border text-center text-xl md:text-3xl tracking-[0.5em] md:tracking-[1em] focus-visible:ring-accent focus-visible:border-accent transition-all font-mono",
                      authError && "border-destructive"
                    )}
                  />
                </div>
                <Button type="submit" className="w-full h-16 md:h-20 bg-primary text-primary-foreground hover:bg-accent transition-all font-bold uppercase tracking-[0.4em] md:tracking-[0.6em] text-[10px] md:text-xs rounded-none shadow-2xl group border-2 border-primary relative overflow-hidden">
                  <span className="relative z-10">Verify Identity</span>
                  <div className="absolute inset-0 bg-accent translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
                </Button>
              </form>

              {authError && (
                <div className="flex items-center justify-center space-x-3 text-destructive animate-pulse bg-destructive/10 p-4 border border-destructive/20">
                  <ShieldAlert className="w-4 h-4 md:w-5 md:h-5" />
                  <span className="text-[9px] md:text-[10px] font-bold uppercase tracking-widest font-mono">CRITICAL: UNAUTHORIZED SEQUENCE</span>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        <Footer />
      </main>
    )
  }

  return (
    <main className="min-h-screen flex flex-col bg-background strategic-grid">
      <Navbar />
      <div className="pt-32 pb-24 container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="mb-12 md:mb-16 strategic-reveal">
            <Badge className="mb-4 bg-accent text-accent-foreground uppercase tracking-[0.3em] md:tracking-[0.5em] px-6 md:px-8 py-2 md:py-3 rounded-none font-bold text-[9px] md:text-xs">Institutional Portal</Badge>
            <h1 className="text-4xl md:text-8xl font-headline font-bold text-primary uppercase leading-none text-balance">Strategic Repository <br /><span className="text-accent italic">Manager.</span></h1>
          </div>
          
          <Tabs defaultValue="publications" className="space-y-12 md:space-y-16">
            <TabsList className="grid grid-cols-2 md:grid-cols-3 bg-secondary/50 p-1 h-16 md:h-20 rounded-none border-2 border-border">
              <TabsTrigger value="publications" className="rounded-none font-bold uppercase tracking-widest text-[9px] md:text-[11px] h-full data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
                <BookOpen className="w-4 h-4 mr-2 md:mr-3" />
                Add Blueprint
              </TabsTrigger>
              <TabsTrigger value="repository" className="rounded-none font-bold uppercase tracking-widest text-[9px] md:text-[11px] h-full data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
                <Layers className="w-4 h-4 mr-2 md:mr-3" />
                Tech Repository
              </TabsTrigger>
              <TabsTrigger value="founder" className="rounded-none font-bold uppercase tracking-widest text-[9px] md:text-[11px] h-full hidden md:flex data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
                <User className="w-4 h-4 mr-2 md:mr-3" />
                CEO Portrait
              </TabsTrigger>
            </TabsList>

            <TabsContent value="publications" className="space-y-12 strategic-reveal">
              <div className="grid lg:grid-cols-12 gap-8 md:gap-16">
                <div className="lg:col-span-8 space-y-12">
                  <Card className="rounded-none border-2 border-border shadow-2xl overflow-hidden bg-background p-1 md:p-2">
                    <CardHeader className="bg-primary text-primary-foreground p-8 md:p-12">
                      <div className="flex items-center space-x-4 mb-4">
                        <Cpu className="w-6 h-6 md:w-8 md:h-8 text-accent" />
                        <CardTitle className="font-headline text-2xl md:text-4xl uppercase tracking-tighter">Publication Abstract</CardTitle>
                      </div>
                      <CardDescription className="text-accent/60 font-mono text-[9px] md:text-xs uppercase tracking-widest">Deploying technical specifications to the library.</CardDescription>
                    </CardHeader>
                    <CardContent className="p-8 md:p-12 space-y-12">
                      <div className="grid md:grid-cols-2 gap-8 md:gap-12">
                        <div className="space-y-4">
                          <Label className="text-[10px] md:text-[11px] uppercase font-bold tracking-[0.3em] text-accent">Technical Title</Label>
                          <Input value={formData.title} onChange={e => setFormData(prev => ({ ...prev, title: e.target.value }))} placeholder="TITLE_STR_001" className="rounded-none border-2 h-14 md:h-16 bg-secondary/10" />
                        </div>
                        <div className="space-y-4">
                          <Label className="text-[10px] md:text-[11px] uppercase font-bold tracking-[0.3em] text-accent">Strategic Tagline</Label>
                          <Input value={formData.tagline} onChange={e => setFormData(prev => ({ ...prev, tagline: e.target.value }))} placeholder="TAG_STR_001" className="rounded-none border-2 h-14 md:h-16 bg-secondary/10" />
                        </div>
                      </div>

                      <div className="space-y-4">
                        <Label className="text-[10px] md:text-[11px] uppercase font-bold tracking-[0.3em] text-accent">Institutional Abstract</Label>
                        <Textarea value={formData.description} onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))} placeholder="Enter full institutional strategic abstract..." className="rounded-none border-2 min-h-[150px] md:min-h-[200px] bg-secondary/10" />
                      </div>

                      <div className="space-y-4">
                        <Label className="text-[10px] md:text-[11px] uppercase font-bold tracking-[0.3em] text-accent">Classification</Label>
                        <Input value={formData.category} onChange={e => setFormData(prev => ({ ...prev, category: e.target.value }))} placeholder="CAT_TYPE_GOV" className="rounded-none border-2 h-14 md:h-16 bg-secondary/10" />
                      </div>

                      {/* Features Matrix */}
                      <div className="space-y-6 pt-12 border-t-2 border-border/50">
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                          <Label className="text-[10px] md:text-[11px] uppercase font-bold tracking-[0.3em] text-accent">Core Technical Features</Label>
                          <Button variant="ghost" size="sm" onClick={addFeature} className="text-[9px] md:text-[11px] uppercase font-bold tracking-widest text-accent hover:bg-accent/10 p-0 sm:p-2">
                            <Plus className="w-4 h-4 mr-2" /> Add Data Point
                          </Button>
                        </div>
                        <div className="space-y-4">
                          {formData.features.map((f, i) => (
                            <div key={i} className="flex gap-4">
                              <Input value={f} onChange={e => updateFeature(i, e.target.value)} placeholder="DATA_ENTRY..." className="rounded-none h-12 md:h-14 border-2" />
                              <Button variant="outline" size="icon" onClick={() => removeFeature(i)} className="rounded-none shrink-0 h-12 md:h-14 w-12 md:w-14 border-destructive/20 text-destructive hover:bg-destructive hover:text-white transition-all">
                                <Trash2 className="w-4 h-4 md:w-5 md:h-5" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Framework Alignment Matrix */}
                      <div className="space-y-6 pt-12 border-t-2 border-border/50">
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                          <Label className="text-[10px] md:text-[11px] uppercase font-bold tracking-[0.3em] text-accent">Alignment Matrix (SDG / ARREST)</Label>
                          <Button variant="ghost" size="sm" onClick={addAlignment} className="text-[9px] md:text-[11px] uppercase font-bold tracking-widest text-accent hover:bg-accent/10 p-0 sm:p-2">
                            <Plus className="w-4 h-4 mr-2" /> Add Matrix Link
                          </Button>
                        </div>
                        <div className="space-y-8">
                          {formData.alignment.map((a, i) => (
                            <Card key={i} className="rounded-none border-2 border-border/50 bg-secondary/5 p-6 md:p-8 space-y-6 relative">
                              <div className="grid md:grid-cols-2 gap-4 md:gap-6">
                                <Input value={a.framework} onChange={e => updateAlignment(i, 'framework', e.target.value)} placeholder="FRAMEWORK_ID" className="h-12 md:h-14 text-sm rounded-none border-2" />
                                <Input value={a.pillar} onChange={e => updateAlignment(i, 'pillar', e.target.value)} placeholder="PILLAR_ID" className="h-12 md:h-14 text-sm rounded-none border-2" />
                              </div>
                              <Textarea value={a.detail} onChange={e => updateAlignment(i, 'detail', e.target.value)} placeholder="STRATEGIC_DETAIL..." className="h-20 md:h-24 text-sm rounded-none border-2" />
                              <Button variant="ghost" size="sm" onClick={() => removeAlignment(i)} className="w-full text-destructive text-[9px] md:text-[10px] uppercase font-bold hover:bg-destructive/10">Purge Data Point</Button>
                            </Card>
                          ))}
                        </div>
                      </div>

                    </CardContent>
                  </Card>
                </div>

                <div className="lg:col-span-4 space-y-12">
                  <Card className="rounded-none border-2 border-border bg-secondary/5 overflow-hidden lg:sticky lg:top-32">
                    <CardHeader className="bg-primary/5 border-b-2 border-border p-6 md:p-8">
                      <CardTitle className="text-xl md:text-2xl font-headline uppercase">Visual Specification</CardTitle>
                      <CardDescription className="text-[9px] md:text-[10px] font-mono uppercase">Upload blueprint imagery.</CardDescription>
                    </CardHeader>
                    <CardContent className="p-8 md:p-10 space-y-8">
                      <div className="relative aspect-[3/4] border-4 border-dashed border-border flex flex-col items-center justify-center bg-background group cursor-pointer overflow-hidden transition-all hover:border-accent">
                        <input type="file" onChange={e => handleImageUpload(e, 'publication')} className="absolute inset-0 opacity-0 cursor-pointer z-10" accept="image/*" />
                        {formData.imageUrl ? (
                          <img src={formData.imageUrl} alt="Preview" className="h-full w-full object-contain p-4" />
                        ) : (
                          <div className="flex flex-col items-center text-center p-6 md:p-8">
                            <Upload className="w-12 h-12 md:w-16 md:h-16 text-accent/20 mb-4 md:mb-6 animate-bounce" />
                            <p className="text-[10px] md:text-[11px] uppercase font-bold tracking-[0.2em] md:tracking-[0.3em] text-muted-foreground leading-relaxed">SELECT TECHNICAL COVER IMAGE</p>
                          </div>
                        )}
                      </div>
                      <Button onClick={handleSavePublication} disabled={isUploading} className="w-full h-20 md:h-24 bg-accent text-accent-foreground font-bold text-[10px] md:text-xs uppercase tracking-[0.4em] md:tracking-[0.5em] rounded-none shadow-2xl hover:translate-y-[-4px] transition-all border-2 border-accent group relative overflow-hidden">
                        <span className="relative z-10 flex items-center justify-center">
                          {isUploading ? <Loader2 className="w-5 h-5 md:w-6 md:h-6 animate-spin mr-3" /> : <Plus className="w-5 h-5 md:w-6 md:h-6 mr-3" />}
                          Commit Blueprint
                        </span>
                        <div className="absolute inset-0 bg-primary translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="repository" className="space-y-12 strategic-reveal">
               <div className="grid gap-6 md:gap-8">
                 {publicationsLoading ? (
                   <div className="flex justify-center py-40">
                     <Loader2 className="w-16 h-16 md:w-20 md:h-20 animate-spin text-accent" />
                   </div>
                 ) : publications?.length === 0 ? (
                   <Card className="rounded-none border-dashed border-4 p-20 md:p-32 text-center bg-secondary/5">
                     <p className="text-muted-foreground uppercase tracking-[0.4em] md:tracking-[0.6em] font-bold text-xs md:text-sm">NO STRATEGIC RECORDS DETECTED.</p>
                   </Card>
                 ) : (
                   publications?.map((p: any) => (
                     <Card key={p.id} className="rounded-none border-2 border-border group hover:border-accent transition-all overflow-hidden flex flex-col lg:flex-row bg-background p-1">
                        <div className="w-full lg:w-48 aspect-[3/4] bg-secondary shrink-0 relative overflow-hidden border-b-2 lg:border-b-0 lg:border-r-2 border-border/50">
                          <img src={p.imageUrl} alt={p.title} className="w-full h-full object-cover grayscale opacity-40 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-1000" />
                          <div className="absolute top-4 left-4">
                             <Badge className="bg-accent/80 backdrop-blur-md text-[8px] md:text-[9px] font-bold uppercase tracking-widest rounded-none border-none">REF_{p.id.slice(0,5)}</Badge>
                          </div>
                        </div>
                        <div className="p-8 md:p-12 flex-1 flex flex-col md:flex-row justify-between items-center gap-8 md:gap-12 w-full">
                          <div className="space-y-4 text-center md:text-left">
                            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 md:gap-4 mb-2">
                               <Badge className="bg-primary text-white text-[9px] md:text-[10px] font-bold uppercase tracking-widest rounded-none px-3 md:px-4 py-1.5">{p.category}</Badge>
                               <span className="text-[10px] md:text-[11px] font-bold uppercase tracking-[0.4em] md:tracking-[0.5em] text-accent italic">{p.tagline}</span>
                            </div>
                            <h3 className="text-2xl md:text-4xl font-headline font-bold text-primary group-hover:text-accent transition-colors uppercase tracking-tight">{p.title}</h3>
                            <p className="text-sm text-muted-foreground line-clamp-2 max-w-2xl font-serif italic border-l-2 border-border pl-6">"{p.description}"</p>
                          </div>
                          <div className="flex flex-col gap-3 md:gap-4 shrink-0 w-full md:w-auto min-w-[200px]">
                            <Button variant="outline" size="lg" asChild className="rounded-none text-[9px] md:text-[10px] uppercase font-bold tracking-widest px-8 h-14 md:h-16 border-2 border-primary hover:bg-primary hover:text-white transition-all">
                              <a href={`/publications/${p.id}`} target="_blank">View Live Audit</a>
                            </Button>
                            <Button onClick={() => handleDeletePublication(p.id)} variant="destructive" size="lg" className="h-14 md:h-16 rounded-none border-2 border-destructive/20 bg-destructive/5 hover:bg-destructive text-destructive hover:text-white transition-all uppercase tracking-widest font-bold text-[9px] md:text-[10px]">
                              <Trash2 className="w-4 h-4 md:w-5 md:h-5 mr-3" />
                              Purge Record
                            </Button>
                          </div>
                        </div>
                     </Card>
                   ))
                 )}
               </div>
            </TabsContent>

            <TabsContent value="founder" className="strategic-reveal">
              <Card className="rounded-none border-2 border-border shadow-2xl bg-background max-w-3xl mx-auto p-1 md:p-2">
                <CardHeader className="bg-primary text-primary-foreground p-8 md:p-16">
                  <div className="flex items-center space-x-4 md:space-x-6 mb-4">
                    <User className="w-10 h-10 md:w-12 md:h-12 text-accent" />
                    <CardTitle className="font-headline text-3xl md:text-5xl uppercase tracking-tighter">CEO Identity Portrait</CardTitle>
                  </div>
                  <CardDescription className="text-accent/60 font-mono text-[10px] md:text-[11px] uppercase tracking-[0.3em] md:tracking-[0.4em]">Managing official leadership record.</CardDescription>
                </CardHeader>
                <CardContent className="p-8 md:p-16 space-y-12">
                  <div className="flex flex-col items-center space-y-8 md:space-y-12">
                    <div className="relative w-full max-w-80 aspect-[3/4] border-4 border-dashed border-border flex flex-col items-center justify-center bg-secondary/5 group cursor-pointer overflow-hidden shadow-2xl transition-all hover:border-accent p-2">
                      <input type="file" onChange={e => handleImageUpload(e, 'founder')} className="absolute inset-0 opacity-0 cursor-pointer z-10" accept="image/*" />
                      {founderImageUrl ? (
                        <img src={founderImageUrl} alt="Founder Preview" className="h-full w-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000" />
                      ) : (
                        <div className="p-8 md:p-12 text-center">
                          <User className="w-16 h-16 md:w-24 md:h-24 text-accent/10 mb-6 md:mb-8 mx-auto animate-pulse" />
                          <p className="text-[10px] md:text-[11px] uppercase font-bold tracking-[0.3em] md:tracking-[0.5em] text-muted-foreground">CLICK TO UPLOAD PORTRAIT</p>
                        </div>
                      )}
                    </div>
                    
                    <div className="text-center space-y-6">
                      <p className="text-[11px] md:text-[12px] uppercase font-bold tracking-[0.5em] md:tracking-[0.6em] text-accent animate-pulse">Sync Protocol Active</p>
                      <p className="text-sm text-muted-foreground max-w-md leading-relaxed italic border-x border-border/50 px-6 md:px-8 py-4 bg-secondary/10">
                        Upload high-definition institutional portraits. This record will be synchronized across all public-facing strategic leadership profiles.
                      </p>
                    </div>

                    <Button 
                      onClick={handleSaveFounder} 
                      disabled={isSavingFounder || founderLoading} 
                      className="w-full h-20 md:h-24 bg-primary text-primary-foreground hover:bg-accent transition-all font-bold rounded-none uppercase tracking-[0.4em] md:tracking-[0.6em] text-[10px] md:text-[11px] shadow-2xl group border-2 border-primary relative overflow-hidden"
                    >
                      <span className="relative z-10 flex items-center justify-center">
                        {isSavingFounder ? <Loader2 className="w-5 h-5 md:w-6 md:h-6 animate-spin mr-3" /> : <Upload className="w-5 h-5 md:w-6 md:h-6 mr-3" />}
                        Synchronize Portrait
                      </span>
                      <div className="absolute inset-0 bg-accent translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <Footer />
    </main>
  )
}

export default ManagePortal