import Navbar from '@/components/layout/Navbar'
import Hero from '@/components/home/Hero'
import FrameworkGrid from '@/components/home/FrameworkGrid'
import ProductSuite from '@/components/home/ProductSuite'
import ConsultancyCalculator from '@/components/home/ConsultancyCalculator'
import ArrestMatrix from '@/components/home/ArrestMatrix'
import ImpactMap from '@/components/home/ImpactMap'
import Footer from '@/components/layout/Footer'

export default function Home() {
  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      <Hero />
      <FrameworkGrid />
      <ProductSuite />
      <ArrestMatrix />
      <ConsultancyCalculator />
      <ImpactMap />
      <Footer />
    </main>
  )
}
