
"use client"

import React from 'react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Target, Eye, ShieldCheck, Heart } from 'lucide-react'

const values = [
  { icon: ShieldCheck, title: "Institutional Integrity", detail: "Maintaining the highest standards of accountability in all consultancy engagements." },
  { icon: Target, title: "Precision Alignment", detail: "Ensuring every strategic plan is meticulously mapped to national frameworks." },
  { icon: Heart, title: "Legacy Building", detail: "Focusing on long-term impact rather than short-term institutional gains." },
  { icon: Eye, title: "Forward Vision", detail: "Anticipating future developmental hurdles and preparing institutional responses." }
]

const AboutPage = () => {
  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-24 bg-primary text-primary-foreground relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl">
            <Badge className="mb-4 bg-accent text-accent-foreground uppercase tracking-[0.3em] px-6 py-1.5 rounded-none font-bold">The Vision & Roots</Badge>
            <h1 className="text-5xl md:text-8xl font-headline font-bold mb-8 leading-tight">Bridging <span className="text-accent italic">Policy</span> <br />and Action.</h1>
            <p className="text-xl opacity-80 leading-relaxed max-w-2xl border-l border-white/20 pl-8 py-2">
              Generational Demands for Sustainable Development Inc. (GDFSD) was founded on the belief that for a nation to rise, its institutional planning must be synchronized with global and continental excellence.
            </p>
          </div>
        </div>
        {/* Abstract background flare */}
        <div className="absolute top-0 right-0 w-1/2 h-full bg-accent/5 blur-[150px] -z-0" />
      </section>

      {/* Mission & Vision */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-16">
            <div className="p-12 bg-secondary/30 border border-border space-y-8">
              <div className="w-12 h-12 bg-accent flex items-center justify-center text-accent-foreground">
                <Target className="w-6 h-6" />
              </div>
              <h2 className="text-4xl font-headline font-bold">Our <span className="text-accent">Mission</span></h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                To serve as Liberia's premier strategic bridge, translating international sustainable development frameworks into localized, actionable, and standardized institutional blueprints for the public and private sectors.
              </p>
            </div>
            <div className="p-12 bg-primary text-primary-foreground border-l-8 border-accent space-y-8">
              <div className="w-12 h-12 bg-white flex items-center justify-center text-primary">
                <Eye className="w-6 h-6" />
              </div>
              <h2 className="text-4xl font-headline font-bold text-white">Our <span className="text-accent">Vision</span></h2>
              <p className="text-lg opacity-80 leading-relaxed">
                A Liberia where every student, every executive, and every institution is perfectly aligned with the continental goal of 'The Africa We Want', driven by evidence-based strategy and deep civic responsibility.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-24 bg-background border-t border-border">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mb-16">
            <h2 className="text-4xl font-headline font-bold mb-6">Foundational <span className="text-accent">Values</span></h2>
            <p className="text-muted-foreground">The pillars upon which GDFSD builds its institutional excellence.</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((v, i) => (
              <div key={i} className="space-y-6 group">
                <div className="w-10 h-10 border border-border flex items-center justify-center group-hover:bg-accent group-hover:border-accent group-hover:text-accent-foreground transition-all">
                  <v.icon className="w-5 h-5" />
                </div>
                <h3 className="text-xl font-headline font-bold">{v.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{v.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

export default AboutPage
