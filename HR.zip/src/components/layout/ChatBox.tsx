'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, Send, X, Bot, User, Loader2, Minus, Sparkles, ChevronRight } from 'lucide-react';
import { systemConsultantChat } from '@/ai/flows/system-consultant-flow';
import { cn } from '@/lib/utils';

type Message = {
  role: 'user' | 'model';
  content: string;
};

const SUGGESTED_QUESTIONS = [
  "How does GDFSD align with the ARREST Agenda?",
  "Tell me about the Executive Sustainability Diary.",
  "What is the significance of the Student Notebook?",
  "How can I request a Strategic Alignment Brief?",
  "Explain GDFSD's role in AU Agenda 2063."
];

export function ChatBox() {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', content: 'Greetings. I am your GDFSD Strategic Consultant. Select a strategic inquiry below or type your message to begin.' }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (textOverride?: string) => {
    const textToSend = textOverride || input.trim();
    if (!textToSend || isLoading) return;

    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: textToSend }]);
    setIsLoading(true);

    try {
      const response = await systemConsultantChat({
        message: textToSend,
        history: messages
      });
      setMessages(prev => [...prev, { role: 'model', content: response.response }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', content: "I apologize, but I am experiencing a temporary synchronization error with our strategic database. Please try again shortly." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-[100] flex flex-col items-end">
      {isOpen ? (
        <Card className="w-[400px] h-[600px] shadow-[0_32px_128px_-16px_rgba(0,0,0,0.5)] border-accent/20 bg-background/95 backdrop-blur-2xl animate-in slide-in-from-bottom-8 duration-500 flex flex-col overflow-hidden rounded-[2rem]">
          <CardHeader className="bg-primary text-primary-foreground p-6 flex flex-row items-center justify-between border-b border-white/5">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center shadow-lg shadow-accent/20">
                <Bot className="w-6 h-6 text-accent-foreground" />
              </div>
              <div>
                <CardTitle className="text-md font-headline font-bold tracking-tight">Strategic Intelligence</CardTitle>
                <div className="flex items-center space-x-2">
                  <span className="w-2 h-2 bg-accent rounded-full animate-pulse" />
                  <span className="text-[9px] uppercase font-bold tracking-[0.3em] opacity-70">Active Consultant</span>
                </div>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="h-10 w-10 text-primary-foreground hover:bg-white/10 rounded-full" onClick={() => setIsOpen(false)}>
              <Minus className="w-5 h-5" />
            </Button>
          </CardHeader>

          <CardContent className="flex-1 p-0 overflow-hidden relative">
            <ScrollArea className="h-full p-6" ref={scrollRef}>
              <div className="space-y-6">
                {messages.map((m, i) => (
                  <div key={i} className={cn("flex w-full animate-in fade-in slide-in-from-bottom-2 duration-500", m.role === 'user' ? "justify-end" : "justify-start")}>
                    <div className={cn(
                      "max-w-[85%] p-4 rounded-3xl text-sm leading-relaxed",
                      m.role === 'user' 
                        ? "bg-accent text-accent-foreground rounded-tr-none shadow-xl shadow-accent/10 font-medium" 
                        : "bg-secondary text-secondary-foreground rounded-tl-none border border-border/50 shadow-sm"
                    )}>
                      {m.content}
                    </div>
                  </div>
                ))}
                
                {messages.length === 1 && !isLoading && (
                  <div className="pt-4 space-y-3">
                    <div className="flex items-center space-x-2 mb-4">
                      <Sparkles className="w-4 h-4 text-accent" />
                      <span className="text-[10px] font-bold uppercase tracking-widest opacity-40">Suggested Strategic Inquiries</span>
                    </div>
                    <div className="grid gap-2">
                      {SUGGESTED_QUESTIONS.map((q, i) => (
                        <button
                          key={i}
                          onClick={() => handleSend(q)}
                          className="text-left p-4 rounded-2xl border border-border/50 bg-background hover:border-accent hover:bg-accent/5 transition-all text-xs font-bold group flex items-center justify-between"
                        >
                          <span className="opacity-80 group-hover:opacity-100 group-hover:text-accent transition-all">{q}</span>
                          <ChevronRight className="w-3 h-3 text-accent opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-secondary p-4 rounded-3xl rounded-tl-none border border-border/50 flex items-center space-x-3 shadow-sm">
                      <Loader2 className="w-4 h-4 animate-spin text-accent" />
                      <span className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-60">Analyzing Frameworks...</span>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
          </CardContent>

          <CardFooter className="p-6 bg-secondary/20 border-t border-border/50">
            <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="flex w-full items-center space-x-3">
              <Input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Submit strategic brief query..." 
                className="bg-background border-border/50 focus:border-accent transition-all rounded-2xl h-14 px-6 text-sm font-medium"
              />
              <Button type="submit" disabled={!input.trim() || isLoading} size="icon" className="h-14 w-14 shrink-0 bg-primary hover:bg-accent rounded-2xl transition-all shadow-xl shadow-primary/20">
                <Send className="w-5 h-5" />
              </Button>
            </form>
          </CardFooter>
        </Card>
      ) : (
        <Button 
          onClick={() => setIsOpen(true)}
          className="w-20 h-20 rounded-[2rem] shadow-[0_24px_64px_-12px_rgba(0,0,0,0.4)] bg-primary text-primary-foreground hover:bg-accent transition-all duration-500 group relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-accent/20 translate-y-full group-hover:translate-y-0 transition-transform duration-700" />
          <div className="relative z-10 flex flex-col items-center">
            <MessageSquare className="w-8 h-8 mb-1 group-hover:scale-110 transition-transform" />
            <span className="text-[8px] font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">Consultant</span>
          </div>
        </Button>
      )}
    </div>
  );
}
