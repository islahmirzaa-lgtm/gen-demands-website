import React from 'react'
import Link from 'next/link'
import { Facebook, Twitter, Linkedin, Mail, Phone, MapPin, Globe } from 'lucide-react'
import { Button } from '@/components/ui/button'

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground pt-32 pb-12 border-t border-white/5">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 mb-24">
          <div className="lg:col-span-5 space-y-8">
            <Link href="/" className="inline-block">
              <span className="text-4xl font-headline font-bold text-accent tracking-tighter">VANTAGE</span>
              <p className="text-[10px] uppercase tracking-[0.5em] font-bold opacity-60 mt-2">Generational Demands Inc.</p>
            </Link>
            <p className="text-lg opacity-80 leading-relaxed max-w-md border-l border-white/20 pl-6">
              Empowering institutions through the vertical integration of national policy and sustainable development excellence. Headquartered in Paynesville, Liberia.
            </p>
            <div className="flex space-x-4">
              {[Facebook, Linkedin, Twitter].map((Icon, i) => (
                <Link key={i} href="#" className="w-12 h-12 border border-white/10 flex items-center justify-center hover:bg-accent hover:text-primary transition-all">
                  <Icon className="w-5 h-5" />
                </Link>
              ))}
            </div>
          </div>

          <div className="lg:col-span-3 space-y-8">
            <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-accent">Strategic Links</h4>
            <ul className="space-y-4 text-sm font-bold uppercase tracking-widest opacity-80">
              <li><Link href="/overview" className="hover:text-accent transition-colors">System Overview</Link></li>
              <li><Link href="/publications" className="hover:text-accent transition-colors">Publication Suite</Link></li>
              <li><Link href="/services" className="hover:text-accent transition-colors">Institutional Consulting</Link></li>
              <li><Link href="/impact" className="hover:text-accent transition-colors">National Impact</Link></li>
            </ul>
          </div>

          <div className="lg:col-span-4 space-y-8">
            <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-accent">Headquarters</h4>
            <ul className="space-y-6 text-sm opacity-80">
              <li className="flex items-start space-x-4">
                <MapPin className="w-5 h-5 text-accent mt-0.5 shrink-0" />
                <span className="leading-relaxed">Duport Road, Adjacent Shara Police Depot, Paynesville, Liberia</span>
              </li>
              <li className="flex items-center space-x-4">
                <Phone className="w-5 h-5 text-accent shrink-0" />
                <span>+231 770 471 560</span>
              </li>
              <li className="flex items-center space-x-4">
                <Mail className="w-5 h-5 text-accent shrink-0" />
                <span>info@gdfsd.org</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex flex-wrap justify-center gap-8 opacity-40 hover:opacity-100 transition-all">
            {['ECOWAS Vision 2050', 'AU Agenda 2063', 'ARREST Agenda', 'SDGs 2030'].map((p, i) => (
              <span key={i} className="text-[9px] font-bold uppercase tracking-widest">{p}</span>
            ))}
          </div>
          <p className="text-[10px] font-bold uppercase tracking-widest opacity-40">
            © {new Date().getFullYear()} Generational Demands for Sustainable Development Inc.
          </p>
        </div>
      </div>
    </footer>
  )
}

export default Footer