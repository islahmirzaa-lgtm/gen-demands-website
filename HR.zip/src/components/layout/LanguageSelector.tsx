"use client"

import React, { useState, useEffect } from 'react'
import { Globe, ChevronDown, Check, Loader2 } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from '@/lib/utils'

const languages = [
  { name: 'English', code: 'en' },
  { name: 'Français', code: 'fr' },
  { name: 'Español', code: 'es' },
  { name: 'Deutsch', code: 'de' },
  { name: '中文', code: 'zh-CN' },
  { name: 'العربية', code: 'ar' },
  { name: 'Português', code: 'pt' },
]

export const LanguageSelector = () => {
  const [currentLang, setCurrentLang] = useState('English')
  const [isSyncing, setIsSyncing] = useState(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleLangChange = (lang: string, code: string) => {
    setIsSyncing(true)
    setCurrentLang(lang)
    
    const select = document.querySelector('.goog-te-combo') as HTMLSelectElement
    if (select) {
      select.value = code
      select.dispatchEvent(new Event('change'))
      setTimeout(() => setIsSyncing(false), 1200)
    } else {
      setIsSyncing(false)
    }
  }

  if (!mounted) return null

  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="flex items-center space-x-4 h-12 md:h-14 px-6 md:px-8 border-2 border-border/60 text-[11px] font-bold uppercase tracking-[0.4em] outline-none hover:bg-accent/10 hover:border-accent transition-all group rounded-none bg-background/50 backdrop-blur-md">
        {isSyncing ? (
          <Loader2 className="w-5 h-5 text-accent animate-spin" />
        ) : (
          <Globe className="w-5 h-5 text-accent group-hover:rotate-12 transition-transform" />
        )}
        <span className="hidden sm:inline">{currentLang}</span>
        <ChevronDown className="w-4 h-4 opacity-30 group-hover:opacity-100 transition-opacity" />
      </DropdownMenuTrigger>
      <DropdownMenuContent className="rounded-none border-4 border-border shadow-[0_32px_128px_-16px_rgba(0,0,0,0.5)] p-2 min-w-[280px] bg-background/98 backdrop-blur-3xl animate-in fade-in zoom-in-95 duration-300 z-[200]">
        <div className="px-5 py-4 border-b-2 border-border/50 mb-3 bg-primary/5">
          <span className="text-[10px] uppercase font-bold tracking-[0.6em] text-accent">Strategic Language Bridge</span>
        </div>
        <div className="grid gap-1">
          {languages.map((lang) => (
            <DropdownMenuItem 
              key={lang.code}
              onClick={() => handleLangChange(lang.name, lang.code)} 
              className={cn(
                "text-[11px] font-bold uppercase tracking-[0.2em] p-5 cursor-pointer focus:bg-accent focus:text-accent-foreground flex items-center justify-between rounded-none transition-all",
                currentLang === lang.name && "bg-accent/10 text-accent"
              )}
            >
              <span>{lang.name}</span>
              {currentLang === lang.name && <Check className="w-4 h-4" />}
            </DropdownMenuItem>
          ))}
        </div>
        <div id="google_translate_element" className="hidden"></div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}