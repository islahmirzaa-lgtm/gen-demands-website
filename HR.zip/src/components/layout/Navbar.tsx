"use client"

import React, { useState, useEffect } from 'react'
import Link from 'next/link'
import { ChevronDown, Menu, Shield, User, Book, Landmark, Globe, Activity, Info, Briefcase } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { ThemeToggle } from './ThemeToggle'
import { LanguageSelector } from './LanguageSelector'
import { SYSTEM_NAME, SYSTEM_TAGLINE } from '@/lib/constants'
import { ScrollArea } from '@/components/ui/scroll-area'

const Navbar = () => {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <nav className="fixed top-0 left-0 right-0 z-[100] h-20 md:h-24 flex items-center bg-background/80 backdrop-blur-3xl border-b-2 border-border/50">
        <div className="container mx-auto px-4 lg:px-12 flex justify-between items-center h-full">
           <div className="flex items-center space-x-3 md:space-x-6">
             <div className="w-10 h-10 md:w-16 md:h-16 bg-primary border-2 border-accent/20" />
             <div className="h-4 w-32 bg-secondary animate-pulse" />
           </div>
        </div>
      </nav>
    )
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-[100] h-20 md:h-24 flex items-center bg-background/80 backdrop-blur-3xl border-b-2 border-border/50 transition-all duration-500">
      <div className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-accent to-transparent opacity-60" />
      
      <div className="container mx-auto px-4 lg:px-12 flex justify-between items-center h-full">
        
        {/* Presidential Logo Architecture */}
        <Link href="/" className="flex items-center space-x-3 md:space-x-6 group shrink-0">
          <div className="relative">
            <div className="w-10 h-10 md:w-16 md:h-16 bg-primary flex items-center justify-center border-2 border-accent/20 group-hover:border-accent transition-all duration-700 relative overflow-hidden shadow-2xl">
              <span className="text-xl md:text-3xl font-headline font-bold text-accent relative z-10">{SYSTEM_NAME.charAt(0)}</span>
              <div className="absolute inset-0 bg-accent translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
            </div>
            <div className="absolute -inset-2 border border-accent/10 -z-10 animate-spin-slow" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm md:text-2xl font-headline font-bold tracking-tighter text-foreground group-hover:text-accent transition-colors leading-none whitespace-nowrap">
              {SYSTEM_NAME}
            </span>
            <span className="text-[7px] md:text-[10px] uppercase font-bold tracking-[0.3em] md:tracking-[0.5em] text-accent/80 mt-1">
              {SYSTEM_TAGLINE}
            </span>
          </div>
        </Link>

        {/* Desktop Strategic Navigation */}
        <div className="hidden xl:flex items-center space-x-10">
          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center space-x-3 text-[11px] font-bold uppercase tracking-[0.5em] hover:text-accent transition-all outline-none">
              <span>Institution</span>
              <ChevronDown className="w-3 h-3 text-accent" />
            </DropdownMenuTrigger>
            <DropdownMenuContent className="rounded-none border-2 border-border shadow-2xl p-2 min-w-[280px] bg-background/98 backdrop-blur-3xl">
              <DropdownMenuItem asChild className="p-5 cursor-pointer rounded-none hover:bg-accent hover:text-accent-foreground transition-all">
                <Link href="/about" className="text-[11px] uppercase font-bold tracking-widest w-full flex items-center"><Info className="mr-3 w-4 h-4"/> Roots & Vision</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild className="p-5 cursor-pointer rounded-none hover:bg-accent hover:text-accent-foreground transition-all">
                <Link href="/founder" className="text-[11px] uppercase font-bold tracking-widest w-full flex items-center"><User className="mr-3 w-4 h-4"/> CEO Profile</Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center space-x-3 text-[11px] font-bold uppercase tracking-[0.5em] hover:text-accent transition-all outline-none">
              <span>Policy Hub</span>
              <ChevronDown className="w-3 h-3 text-accent" />
            </DropdownMenuTrigger>
            <DropdownMenuContent className="rounded-none border-2 border-border shadow-2xl p-2 min-w-[280px] bg-background/98 backdrop-blur-3xl">
              <DropdownMenuItem asChild className="p-5 cursor-pointer rounded-none hover:bg-accent hover:text-accent-foreground transition-all">
                <Link href="/agenda/arrest" className="text-[11px] uppercase font-bold tracking-widest w-full flex items-center"><Landmark className="mr-3 w-4 h-4"/> ARREST Agenda</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild className="p-5 cursor-pointer rounded-none hover:bg-accent hover:text-accent-foreground transition-all">
                <Link href="/agenda/2063" className="text-[11px] uppercase font-bold tracking-widest w-full flex items-center"><Globe className="mr-3 w-4 h-4"/> Agenda 2063</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild className="p-5 cursor-pointer rounded-none hover:bg-accent hover:text-accent-foreground transition-all">
                <Link href="/impact" className="text-[11px] uppercase font-bold tracking-widest w-full flex items-center"><Activity className="mr-3 w-4 h-4"/> Impact Data</Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Link href="/publications" className="text-[11px] font-bold uppercase tracking-[0.5em] hover:text-accent transition-all">Library</Link>
          <Link href="/services" className="text-[11px] font-bold uppercase tracking-[0.5em] hover:text-accent transition-all">Consulting</Link>
        </div>

        {/* Global Controls */}
        <div className="flex items-center space-x-3 md:space-x-6">
          <div className="hidden lg:flex items-center space-x-4">
            <LanguageSelector />
            <ThemeToggle />
          </div>
          
          <Button variant="outline" className="h-10 md:h-14 px-4 md:px-8 rounded-none border-2 border-accent/40 bg-accent/5 text-accent hover:bg-accent hover:text-accent-foreground transition-all duration-500 font-bold uppercase tracking-[0.3em] text-[9px] md:text-[11px] group shadow-2xl shrink-0" asChild>
            <Link href="/portal/manage">
              <Shield className="w-3 h-3 md:w-4 md:h-4 mr-2 md:mr-3 group-hover:rotate-12 transition-transform" />
              Portal
            </Link>
          </Button>

          {/* Mobile Sheet */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="xl:hidden h-10 w-10 border-2 border-border/50 bg-secondary/20 shrink-0">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-background/98 backdrop-blur-3xl border-l-4 border-accent/20 w-full sm:w-[450px] p-0 flex flex-col z-[300]">
              <div className="p-8 border-b-2 border-border/50 flex justify-between items-center bg-primary/5">
                <div className="space-y-1">
                  <span className="text-lg font-headline font-bold uppercase tracking-[0.3em] text-accent block">Command Center</span>
                  <span className="text-[9px] uppercase font-bold tracking-widest opacity-40">SYSTEM_AUTH_V2.5.9</span>
                </div>
                <div className="flex items-center space-x-3">
                   <ThemeToggle />
                </div>
              </div>
              <ScrollArea className="flex-1">
                <div className="p-8 space-y-12">
                   <div className="space-y-4">
                     <span className="text-[11px] uppercase font-bold tracking-[0.6em] text-accent opacity-60">Strategic Sections</span>
                     {[
                       { href: "/about", label: "Roots & Vision", icon: Info },
                       { href: "/founder", label: "CEO Profile", icon: User },
                       { href: "/agenda/arrest", label: "ARREST Agenda", icon: Landmark },
                       { href: "/agenda/2063", label: "Agenda 2063", icon: Globe },
                       { href: "/publications", label: "Strategic Library", icon: Book },
                       { href: "/services", label: "Institutional Consulting", icon: Briefcase },
                       { href: "/impact", label: "National Impact", icon: Activity },
                     ].map((item) => (
                       <Link key={item.href} href={item.href} className="flex items-center space-x-5 p-5 bg-secondary/30 border-2 border-transparent hover:border-accent/40 group transition-all">
                         <item.icon className="w-5 h-5 text-accent group-hover:scale-110 transition-transform" />
                         <span className="text-xs font-bold uppercase tracking-[0.2em]">{item.label}</span>
                       </Link>
                     ))}
                   </div>
                </div>
              </ScrollArea>
              <div className="p-8 border-t-4 border-accent bg-primary text-primary-foreground">
                <LanguageSelector />
                <p className="text-[11px] uppercase font-bold tracking-[0.4em] text-accent/80 mt-6 mb-2">Institutional Integrity</p>
                <p className="text-xs opacity-60 leading-relaxed">Strategic Multi-Language Bridge Active.</p>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  )
}

export default Navbar