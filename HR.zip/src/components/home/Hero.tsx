"use client"

import React, { useState, useEffect } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ArrowRight, Orbit, ShieldCheck, Zap, Activity } from 'lucide-react'
import { PlaceHolderImages } from '@/lib/placeholder-images'
import { STRATEGIC_HORIZON, SYSTEM_NAME } from '@/lib/constants'

const Hero = () => {
  const [timeLeft, setTimeLeft] = useState({ years: 0, days: 0 })

  useEffect(() => {
    const target = new Date(STRATEGIC_HORIZON).getTime()
    const updateTicker = () => {
      const now = new Date().getTime()
      const diff = target - now
      const years = Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25))
      const days = Math.floor((diff % (1000 * 60 * 60 * 24 * 365.25)) / (1000 * 60 * 60 * 24))
      setTimeLeft({ years, days })
    }
    updateTicker()
    const interval = setInterval(updateTicker, 1000)
    return () => clearInterval(interval)
  }, [])

  const heroImage = PlaceHolderImages.find(img => img.id === 'hero-bg')

  return (
    <section className="relative min-h-screen flex items-center bg-background pt-32 md:pt-40 pb-24 md:pb-32 border-b-4 border-accent/20 strategic-grid overflow-hidden transition-colors duration-700">
      {/* Structural Accents - One in a Million Design */}
      <div className="absolute top-0 right-0 w-[45%] h-full border-l-2 border-accent/10 pointer-events-none hidden lg:block" />
      <div className="absolute -top-[10%] -right-[5%] w-[1000px] h-[1000px] bg-accent/5 rounded-full blur-[250px] animate-pulse pointer-events-none" />
      
      <div className="container mx-auto px-4 md:px-12 relative z-10">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-24 items-center">
          
          <div className="lg:col-span-8 space-y-12 md:space-y-16">
            <div className="space-y-8 md:space-y-10 strategic-reveal">
              <div className="flex items-center space-x-4 md:space-x-8">
                <Badge className="bg-accent/10 text-accent rounded-none px-4 md:px-8 py-2 md:py-3 uppercase tracking-[0.4em] md:tracking-[0.6em] font-bold text-[9px] md:text-[11px] border-2 border-accent/20 shadow-xl whitespace-nowrap">
                  Strategic Hub
                </Badge>
                <div className="flex-1 h-[2px] bg-accent/20" />
              </div>

              <div className="space-y-6">
                <h1 className="text-4xl md:text-[8.5rem] font-headline font-bold leading-[0.9] text-foreground tracking-tighter uppercase transition-colors duration-700 text-balance">
                  Presidential <br />
                  <span className="text-accent italic">Legacy.</span>
                </h1>
                
                <div className="max-w-3xl mt-8 md:mt-16 pl-6 md:pl-12 border-l-4 md:border-l-8 border-accent bg-accent/5 backdrop-blur-xl relative py-6 md:py-10 shadow-2xl">
                  <p className="text-lg md:text-4xl font-headline font-medium text-foreground/80 leading-snug italic transition-colors duration-700 text-balance">
                    "Synchronizing global policy vision with Liberian national implementation protocols."
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 md:gap-8 pt-4 md:pt-8 strategic-reveal" style={{ animationDelay: '0.2s' }}>
              <Button size="lg" className="h-16 md:h-24 px-8 md:px-16 rounded-none bg-primary text-primary-foreground hover:bg-accent transition-all duration-700 text-[10px] md:text-[12px] font-bold tracking-[0.3em] md:tracking-[0.5em] uppercase shadow-2xl group relative overflow-hidden" asChild>
                <Link href="/services">
                  <span className="relative z-10">Engage Consultancy</span>
                  <ArrowRight className="ml-3 md:ml-5 w-4 h-4 md:w-6 md:h-6 group-hover:translate-x-3 transition-transform relative z-10" />
                  <div className="absolute inset-0 bg-accent translate-y-full group-hover:translate-y-0 transition-transform duration-700" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="h-16 md:h-24 px-8 md:px-16 rounded-none border-2 md:border-4 border-accent/20 text-foreground hover:bg-accent/10 hover:border-accent transition-all text-[10px] md:text-[12px] font-bold tracking-[0.3em] md:tracking-[0.5em] uppercase shadow-xl" asChild>
                <Link href="/publications">
                  Explore Library
                </Link>
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 md:gap-12 pt-12 md:pt-20 border-t-2 border-accent/10 strategic-reveal" style={{ animationDelay: '0.4s' }}>
              {[
                { icon: ShieldCheck, label: "Institutional Integrity" },
                { icon: Activity, label: "Strategic Precision" },
                { icon: Zap, label: "Legacy Frameworks" }
              ].map((stat, i) => (
                <div key={i} className="flex items-center space-x-4 opacity-40 hover:opacity-100 transition-all group cursor-default">
                  <stat.icon className="w-5 h-5 md:w-6 md:h-6 text-accent group-hover:scale-125 transition-transform" />
                  <span className="text-[9px] md:text-[11px] uppercase font-bold tracking-[0.3em] md:tracking-[0.4em]">{stat.label}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-4 relative hidden lg:block strategic-reveal" style={{ animationDelay: '0.6s' }}>
            <div className="relative aspect-[3/4] blueprint-card border-[20px] border-background shadow-[0_64px_128px_-12px_rgba(0,0,0,0.5)] group overflow-hidden">
              <Image
                src={heroImage?.imageUrl || ''}
                alt={SYSTEM_NAME}
                fill
                className="object-cover grayscale group-hover:grayscale-0 transition-all duration-1000 scale-105 group-hover:scale-100"
                priority
              />
              <div className="absolute top-6 left-6 z-20 text-[10px] font-mono text-accent/90 bg-background/95 px-4 py-2 border-2 border-accent/30 shadow-2xl">COORD: 6.31N / 10.80W</div>
              <div className="absolute inset-0 bg-accent/10 opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
            </div>

            {/* Circular Countdown Dashboard */}
            <div className="absolute -bottom-16 -left-16 bg-background/98 backdrop-blur-3xl p-8 md:p-12 border-4 border-accent/20 shadow-[0_48px_128px_-12px_rgba(0,0,0,0.6)] animate-float hidden xl:block">
              <div className="space-y-8">
                <div className="flex items-center space-x-4">
                  <Orbit className="w-8 h-8 text-accent animate-spin-slow" />
                  <span className="text-[11px] uppercase font-bold tracking-[0.6em] text-accent">Maturity Window</span>
                </div>
                <div className="flex items-baseline space-x-4">
                  <span className="text-8xl font-headline font-bold text-foreground tracking-tighter">{timeLeft.years}</span>
                  <span className="text-3xl font-headline font-bold text-accent italic opacity-70">Years</span>
                </div>
                <div className="space-y-4">
                  <div className="text-[11px] uppercase font-bold tracking-[0.5em] text-muted-foreground border-t-2 border-accent/10 pt-6">Strategic Horizon: 2063</div>
                  <div className="w-full h-2.5 bg-secondary/40 border-2 border-accent/10 relative overflow-hidden shadow-inner">
                     <div className="h-full bg-accent shadow-[0_0_20px_rgba(var(--accent),0.5)]" style={{ width: '42.5%' }} />
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  )
}

export default Hero