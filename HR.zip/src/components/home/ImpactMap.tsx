"use client"

import React from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { MapPin, Users, BookOpen, GraduationCap } from 'lucide-react'

const stats = [
  { icon: GraduationCap, label: "Schools Reached", value: "450+" },
  { icon: Users, label: "Public Servants", value: "12,000+" },
  { icon: BookOpen, label: "Legacy Books", value: "50,000+" },
]

const ImpactMap = () => {
  return (
    <section className="py-24 relative overflow-hidden bg-background">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-5 gap-12 items-center">
          <div className="lg:col-span-2">
            <Badge className="mb-4 bg-accent/20 text-accent border-accent/20 uppercase tracking-widest px-4 py-1">National Footprint</Badge>
            <h2 className="text-4xl md:text-5xl font-headline font-bold mb-6">Liberia's Map <br />of Impact</h2>
            <p className="text-muted-foreground text-lg mb-10 leading-relaxed">
              From the classrooms of rural Nimba to the ministerial suites of Monrovia, GDFSD publications are sparking change and building legacies across every county in Liberia.
            </p>

            <div className="space-y-6">
              {stats.map((s, i) => (
                <div key={i} className="flex items-center space-x-6 p-6 rounded-2xl glass-panel border-white/5">
                  <div className="w-14 h-14 rounded-full bg-accent/10 flex items-center justify-center">
                    <s.icon className="w-7 h-7 text-accent" />
                  </div>
                  <div>
                    <div className="text-3xl font-bold font-headline text-accent">{s.value}</div>
                    <div className="text-xs uppercase font-bold tracking-widest text-muted-foreground">{s.label}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-3 relative">
            <Card className="glass-panel border-white/5 p-4 overflow-hidden min-h-[500px] flex items-center justify-center group">
              {/* This would ideally be a real Vis.GL map, but using a high-end SVG illustration for reliability & design control */}
              <div className="relative w-full aspect-square max-w-lg">
                <svg viewBox="0 0 400 300" className="w-full h-full text-accent/20 fill-current">
                  {/* Simplified Liberia shape */}
                  <path d="M100,50 L200,30 L350,100 L380,200 L300,280 L150,250 L50,150 Z" />
                </svg>
                
                {/* Hotspots */}
                <div className="absolute top-[20%] left-[30%] animate-pulse">
                  <div className="relative group">
                    <MapPin className="w-8 h-8 text-accent cursor-pointer" />
                    <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-primary px-3 py-1 rounded text-[10px] font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                      Montserrado (Monrovia) - 8,500 Users
                    </div>
                  </div>
                </div>

                <div className="absolute top-[40%] right-[30%] delay-300 animate-pulse">
                  <div className="relative group">
                    <MapPin className="w-6 h-6 text-accent/60 cursor-pointer" />
                    <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-primary px-3 py-1 rounded text-[10px] font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                      Nimba County - 120 Schools
                    </div>
                  </div>
                </div>

                <div className="absolute bottom-[30%] left-[25%] delay-500 animate-pulse">
                  <div className="relative group">
                    <MapPin className="w-5 h-5 text-accent/40 cursor-pointer" />
                    <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-primary px-3 py-1 rounded text-[10px] font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                      Grand Bassa - 45 Institutions
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="absolute inset-0 bg-gradient-to-t from-background/40 to-transparent pointer-events-none" />
              <div className="absolute bottom-6 left-6 right-6 p-4 glass-panel border-white/5 rounded-xl flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-widest">Live Presence Data</span>
                <Badge variant="outline" className="text-accent border-accent/20 animate-pulse">UPDATING MONTHLY</Badge>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}

export default ImpactMap
