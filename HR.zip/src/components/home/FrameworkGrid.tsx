"use client"

import React from 'react'
import { Badge } from '@/components/ui/badge'
import { ShieldCheck, Landmark, Globe, ArrowUpRight } from 'lucide-react'
import Link from 'next/link'

const frameworks = [
  {
    name: "ARREST Agenda",
    code: "NTL-LR-01",
    description: "The primary engine for Liberia's national recovery through Agriculture, Roads, and Rule of Law.",
    pillars: ["Agriculture", "Infrastructure", "Rule of Law"],
    icon: Landmark,
    href: "/agenda/arrest"
  },
  {
    name: "AU Agenda 2063",
    code: "AFR-AU-02",
    description: "The Pan-African masterplan for global influence and continental sustainable prosperity.",
    pillars: ["Unity", "Prosperity", "Peace"],
    icon: Globe,
    href: "/agenda/2063"
  },
  {
    name: "UN SDGs 2030",
    code: "GLB-UN-03",
    description: "Universal developmental imperatives for global sustainability and humanitarian dignity.",
    pillars: ["Education", "Quality", "Peace"],
    icon: ShieldCheck,
    href: "/impact"
  }
]

const FrameworkGrid = () => {
  return (
    <section className="py-24 md:py-40 bg-background relative overflow-hidden border-y border-border transition-colors duration-500">
      {/* Structural Line System */}
      <div className="absolute inset-0 grid grid-cols-6 md:grid-cols-12 opacity-[0.05] pointer-events-none">
        {[...Array(13)].map((_, i) => (
          <div key={i} className="h-full border-r border-accent" />
        ))}
      </div>

      <div className="container mx-auto px-6 lg:px-12 relative z-10">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end mb-16 md:mb-32 gap-10 animate-reveal">
          <div className="max-w-4xl space-y-4 md:space-y-8">
            <span className="text-[9px] md:text-[11px] uppercase font-bold tracking-[0.4em] md:tracking-[0.5em] text-accent">Strategic Synchronization</span>
            <h2 className="text-4xl md:text-8xl font-headline font-bold text-foreground leading-[1] md:leading-[0.9] uppercase transition-colors duration-500 text-balance">
              Structural <br /><span className="text-accent italic">Frameworks.</span>
            </h2>
          </div>
          <p className="text-sm md:text-xl text-muted-foreground italic max-w-sm lg:text-right border-l-4 lg:border-l-0 lg:border-r-4 border-accent pl-6 lg:pl-0 lg:pr-10 py-6 bg-accent/5 backdrop-blur-sm transition-colors duration-500">
            Harmonizing global vision with Liberian national implementation protocols.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 bg-accent/10 gap-[2px] shadow-2xl overflow-hidden border-2 border-accent/20">
          {frameworks.map((f, i) => (
            <Link key={i} href={f.href} className="group relative bg-background p-8 md:p-16 flex flex-col min-h-[400px] md:min-h-[550px] transition-all duration-700 hover:bg-accent/[0.03]">
              <div className="absolute top-8 right-8 md:top-12 md:right-12">
                <span className="text-[9px] md:text-[11px] font-mono font-bold text-accent opacity-30 group-hover:opacity-100 transition-all">{f.code}</span>
              </div>
              
              <div className="mb-8 md:mb-20 w-12 h-12 md:w-20 md:h-20 bg-primary flex items-center justify-center border-2 border-accent/20 group-hover:border-accent group-hover:bg-accent group-hover:text-accent-foreground transition-all duration-700 shadow-xl">
                <f.icon className="w-6 h-6 md:w-10 md:h-10" />
              </div>

              <div className="flex-1 space-y-6 md:space-y-8">
                <h3 className="text-2xl md:text-4xl font-headline font-bold text-foreground transition-colors group-hover:text-accent duration-500 leading-tight">
                  {f.name}
                </h3>
                <p className="text-sm md:text-lg text-muted-foreground leading-relaxed opacity-80 group-hover:opacity-100 transition-opacity">
                  {f.description}
                </p>
              </div>

              <div className="pt-8 md:pt-12 mt-8 md:mt-12 border-t-2 border-accent/10 space-y-8 md:space-y-12">
                <div className="flex flex-wrap gap-2 md:gap-3">
                  {f.pillars.map((p, pi) => (
                    <span key={pi} className="text-[7px] md:text-[10px] font-bold uppercase tracking-[0.2em] md:tracking-[0.3em] px-3 md:px-5 py-2 md:py-2.5 bg-accent/5 text-foreground border border-accent/20 group-hover:border-accent group-hover:bg-accent/10 transition-colors">
                      {p}
                    </span>
                  ))}
                </div>
                <div className="flex items-center text-[9px] md:text-[11px] font-bold uppercase tracking-[0.4em] md:tracking-[0.5em] text-accent group-hover:translate-x-4 transition-transform">
                  <span>Verify Alignment</span>
                  <ArrowUpRight className="ml-2 md:ml-4 w-4 h-4" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}

export default FrameworkGrid