
"use client"

import React, { useState } from 'react'
import Link from 'next/link'
import { generateFrameworkAlignmentReport, type FrameworkAlignmentReportOutput } from '@/ai/flows/framework-alignment-report-generator'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Loader2, FileText, CheckCircle2, Send, ArrowRight } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { Badge } from '@/components/ui/badge'

const ConsultancyCalculator = () => {
  const [sector, setSector] = useState<'Education' | 'Finance' | 'Agriculture' | ''>('')
  const [isLoading, setIsLoading] = useState(false)
  const [report, setReport] = useState<FrameworkAlignmentReportOutput | null>(null)
  const { toast } = useToast()

  const handleGenerate = async () => {
    if (!sector) return
    setIsLoading(true)
    try {
      const result = await generateFrameworkAlignmentReport({ sector: sector as any })
      setReport(result)
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Generation Error",
        description: "Failed to generate alignment report. Please try again."
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <section className="py-24 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <Badge className="mb-4 bg-primary/20 text-accent border-accent/20 uppercase tracking-widest px-4 py-1">Institutional Intelligence</Badge>
            <h2 className="text-4xl md:text-5xl font-headline font-bold mb-6">Alignment Preview <br />for Institutional Leaders</h2>
            <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
              Select your institutional sector to see an instant AI-powered preview of how GDFSD consultancy and publications can align your internal planning with national and global frameworks.
            </p>

            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Select Institutional Sector</label>
                  <Select onValueChange={(val: any) => setSector(val)}>
                    <SelectTrigger className="h-14 bg-background border-white/10 text-md">
                      <SelectValue placeholder="Chose Sector..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Education">Ministry of Education / Schools</SelectItem>
                      <SelectItem value="Finance">Ministry of Finance / Commercial Banks</SelectItem>
                      <SelectItem value="Agriculture">Ministry of Agriculture / NGOs</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Button 
                onClick={handleGenerate} 
                disabled={!sector || isLoading}
                className="w-full h-14 bg-accent text-accent-foreground font-bold text-md group"
              >
                {isLoading ? (
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                ) : (
                  <FileText className="mr-2 h-5 w-5" />
                )}
                Generate Alignment Report Preview
              </Button>

              <div className="flex items-center space-x-6 pt-4 border-t border-white/10">
                <div className="flex -space-x-2">
                  {['GBG', 'MOE', 'AU'].map((label, i) => (
                    <div key={i} className="w-8 h-8 rounded-full border-2 border-background bg-accent flex items-center justify-center text-[10px] font-bold text-accent-foreground">
                      {label}
                    </div>
                  ))}
                </div>
                <span className="text-xs text-muted-foreground italic">Trusted by experts from MOE, AU, and ECOWAS.</span>
              </div>
            </div>
          </div>

          <div className="relative">
            {report ? (
              <Card className="glass-panel border-accent/20 animate-in fade-in slide-in-from-right-4 duration-500 overflow-hidden">
                <CardHeader className="bg-primary/50 border-b border-white/5">
                  <div className="flex justify-between items-center">
                    <CardTitle className="font-headline text-accent">Strategic Preview</CardTitle>
                    <Badge variant="outline" className="border-accent/20 text-accent">CONFIDENTIAL PREVIEW</Badge>
                  </div>
                  <CardDescription>Generated alignment report for {sector} sector</CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="p-8 max-h-[400px] overflow-y-auto custom-scrollbar prose prose-invert prose-sm">
                    <div className="whitespace-pre-line text-muted-foreground leading-relaxed">
                      {report.report}
                    </div>
                  </div>
                  <div className="p-6 bg-primary/20 flex flex-col sm:flex-row gap-4 justify-between items-center">
                    <p className="text-xs text-muted-foreground font-medium">Ready for vertical integration?</p>
                    <Button size="sm" className="bg-accent text-accent-foreground space-x-2" asChild>
                      <Link href="/services/apply">
                        <Send className="w-3 h-3" />
                        <span>Apply for Full Brief</span>
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="aspect-[4/5] rounded-2xl border-2 border-dashed border-white/10 flex flex-col items-center justify-center p-12 text-center group">
                <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <FileText className="w-10 h-10 text-muted-foreground opacity-50" />
                </div>
                <h3 className="text-xl font-headline font-bold mb-2">Report Viewer</h3>
                <p className="text-sm text-muted-foreground">Select a sector and generate a preview to see GDFSD's framework alignment strategy.</p>
              </div>
            )}
            
            {/* Background elements */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-accent/10 blur-[100px] -z-10" />
            <div className="absolute -bottom-10 -left-10 w-60 h-60 bg-primary/20 blur-[120px] -z-10" />
          </div>
        </div>
      </div>
    </section>
  )
}

export default ConsultancyCalculator
