"use client"

import React from 'react'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { CheckCircle2, ChevronRight } from 'lucide-react'

const matrixData = [
  { pillar: "Agriculture", product: "Student Notebook", alignment: "Integrating sustainable farming modules for secondary students.", status: "Primary Focus" },
  { pillar: "Roads", product: "Executive Diary", alignment: "Strategic planning for long-term infrastructure maintenance & legacy.", status: "Strategic" },
  { pillar: "Rule of Law", product: "Executive Diary", alignment: "Institutional planning frameworks that uphold accountability.", status: "Governance" },
  { pillar: "Education", product: "Agenda 2063 Notebook", alignment: "Direct integration of civic education into the national curriculum.", status: "Direct" },
  { pillar: "Sanitation", product: "Impact Consultancy", alignment: "Waste management advocacy & urban planning framework support.", status: "Institutional" },
  { pillar: "Tourism", product: "Spark of Freedom", alignment: "Reclaiming Liberian history to drive heritage-based tourism.", status: "Cultural" },
]

const ArrestMatrix = () => {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <Badge className="mb-4 bg-accent/20 text-accent border-accent/20 uppercase tracking-widest px-4 py-1">Policy Integration</Badge>
          <h2 className="text-4xl md:text-5xl font-headline font-bold mb-6">The ARREST Strategy Matrix</h2>
          <p className="text-muted-foreground text-lg">
            Our specialized mapping tool demonstrates exactly how GDFSD products support the six core pillars of the national development agenda.
          </p>
        </div>

        <div className="max-w-5xl mx-auto glass-panel border-white/5 rounded-3xl overflow-hidden shadow-2xl">
          <Table>
            <TableHeader className="bg-primary/50">
              <TableRow className="border-white/5">
                <TableHead className="font-bold uppercase tracking-widest text-xs py-6">ARREST Pillar</TableHead>
                <TableHead className="font-bold uppercase tracking-widest text-xs">Primary GDFSD Tool</TableHead>
                <TableHead className="font-bold uppercase tracking-widest text-xs">Strategic Alignment Detail</TableHead>
                <TableHead className="font-bold uppercase tracking-widest text-xs text-right">Impact Mode</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {matrixData.map((m, i) => (
                <TableRow key={i} className="border-white/5 hover:bg-white/5 transition-colors group">
                  <TableCell className="py-6">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                      <span className="font-bold text-accent">{m.pillar}</span>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium text-foreground">{m.product}</TableCell>
                  <TableCell className="text-muted-foreground text-sm italic">{m.alignment}</TableCell>
                  <TableCell className="text-right">
                    <Badge className="bg-white/5 text-muted-foreground border-white/10 group-hover:bg-accent group-hover:text-accent-foreground transition-all">
                      {m.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          <div className="p-8 bg-primary/20 flex flex-col sm:flex-row justify-between items-center border-t border-white/10">
            <p className="text-sm text-muted-foreground mb-4 sm:mb-0">Need a specialized alignment report for your specific ministry or bureau?</p>
            <Button className="bg-accent text-accent-foreground font-bold space-x-2">
              <span>Request Strategic Brief</span>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

export default ArrestMatrix
