"use client"

import React from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { PlaceHolderImages } from '@/lib/placeholder-images'
import { ArrowRight, Box } from 'lucide-react'
import { Badge } from '@/components/ui/badge'

const products = [
  {
    id: 'executive-diary',
    title: "Executive Sustainability Diary",
    tagline: "The Leader's Legacy",
    description: "A precision institutional framework for performance tracking and long-term legacy planning.",
    image: 'executive-diary',
    category: "Governance"
  },
  {
    id: 'student-notebook',
    title: "Agenda 2063: The Student Notebook",
    tagline: "The Student's Blueprint",
    description: "Directly integrating civic responsibility and Pan-Africanism into the Liberian classroom.",
    image: 'student-notebook',
    category: "Education"
  },
  {
    id: 'spark-of-freedom',
    title: "Liberia: The Spark of Africa's Freedom",
    tagline: "The Nation's Memory",
    description: "An authoritative historical suite reclaiming the African narrative through meticulous research.",
    image: 'spark-of-freedom',
    category: "History"
  },
  {
    id: 'dream-to-destiny',
    title: "From Dream to Destiny",
    tagline: "The Architect's Guide",
    description: "Strategic leadership tools for transitioning from vision to tangible institutional execution.",
    image: 'dream-to-destiny',
    category: "Leadership"
  }
]

const ProductSuite = () => {
  return (
    <section className="py-40 bg-background relative overflow-hidden strategic-grid transition-colors duration-500">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mb-32 space-y-10 strategic-reveal">
          <Badge className="bg-accent/10 text-accent border-accent/20 uppercase tracking-[0.5em] px-8 py-3 font-bold rounded-none border-2">Technical Abstract Suite</Badge>
          <h2 className="text-6xl md:text-9xl font-headline font-bold text-foreground leading-[0.8] tracking-tighter uppercase transition-colors duration-500">
            Strategic <br /><span className="text-accent italic">Library.</span>
          </h2>
          <p className="text-2xl text-muted-foreground leading-relaxed max-w-2xl border-l-4 border-accent pl-12 font-serif transition-colors duration-500">
            Standardizing developmental principles through a curated suite of strategic tools designed for national transformation.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-16">
          {products.map((p, i) => {
            const imgData = PlaceHolderImages.find(img => img.id === p.image)
            return (
              <div key={i} className="group flex flex-col blueprint-card strategic-reveal p-6 md:p-8 hover:bg-accent/[0.02]" style={{ animationDelay: `${i * 0.15}s` }}>
                <div className="relative aspect-[3/4] mb-12 overflow-hidden shadow-2xl border-2 border-accent/10 bg-secondary/10 group">
                  <Image
                    src={imgData?.imageUrl || ''}
                    alt={p.title}
                    fill
                    className="object-cover grayscale group-hover:grayscale-0 transition-all duration-1000 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-primary/80 opacity-0 group-hover:opacity-100 transition-opacity duration-700 flex items-center justify-center p-12 text-center backdrop-blur-md">
                    <Button variant="secondary" className="rounded-none uppercase tracking-[0.4em] text-[11px] font-bold h-16 w-full border-2 border-accent text-accent bg-transparent hover:bg-accent hover:text-accent-foreground transition-all" asChild>
                      <Link href={`/publications/${p.id}`}>Analyze Specs</Link>
                    </Button>
                  </div>
                  <div className="absolute top-6 left-6 z-20">
                    <span className="bg-primary text-primary-foreground text-[10px] font-bold uppercase tracking-widest px-5 py-2.5 border border-accent/30 shadow-2xl">
                      {p.category}
                    </span>
                  </div>
                </div>
                
                <div className="space-y-8 flex-1">
                  <div className="flex items-center space-x-4 text-[10px] font-bold uppercase tracking-[0.5em] text-accent">
                    <Box className="w-5 h-5" />
                    <span>{p.tagline}</span>
                  </div>
                  <h3 className="text-3xl font-headline font-bold text-foreground group-hover:text-accent transition-colors leading-[1.1] duration-500">{p.title}</h3>
                  <p className="text-base text-muted-foreground leading-relaxed italic opacity-80 border-l-2 border-accent/20 pl-6 transition-colors duration-500">
                    "{p.description}"
                  </p>
                  <div className="pt-8 mt-auto flex justify-between items-center border-t-2 border-accent/10">
                    <Link href={`/publications/${p.id}`} className="inline-flex items-center text-[11px] font-bold uppercase tracking-[0.5em] text-foreground hover:text-accent transition-all group-hover:translate-x-4">
                      Technical Audit
                      <ArrowRight className="ml-5 w-5 h-5" />
                    </Link>
                    <span className="text-[10px] font-mono text-accent/40 font-bold uppercase">v2.5.9</span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}

export default ProductSuite