import { config } from 'dotenv';
config();

import '@/ai/flows/framework-alignment-report-generator.ts';
import '@/ai/flows/holiday-significance-generator.ts';
import '@/ai/flows/system-consultant-flow.ts';
