'use server';
/**
 * @fileOverview A Genkit flow for the GDFSD Strategic Consultant AI.
 * 
 * - systemConsultantChat - Handles conversational queries about GDFSD, its publications, and policy alignment.
 * - SystemConsultantInput - Input type for the chat.
 * - SystemConsultantOutput - Output type for the chat.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const SystemConsultantInputSchema = z.object({
  message: z.string().describe('The user\'s question or message.'),
  history: z.array(z.object({
    role: z.enum(['user', 'model']),
    content: z.string()
  })).optional().describe('Chat history for context.'),
});
export type SystemConsultantInput = z.infer<typeof SystemConsultantInputSchema>;

const SystemConsultantOutputSchema = z.object({
  response: z.string().describe('The AI-generated response.'),
});
export type SystemConsultantOutput = z.infer<typeof SystemConsultantOutputSchema>;

export async function systemConsultantChat(input: SystemConsultantInput): Promise<SystemConsultantOutput> {
  return systemConsultantFlow(input);
}

const systemConsultantPrompt = ai.definePrompt({
  name: 'systemConsultantPrompt',
  input: { schema: SystemConsultantInputSchema },
  output: { schema: SystemConsultantOutputSchema },
  prompt: `You are the Lead Strategic Consultant for Generational Demands for Sustainable Development Inc. (GDFSD). 
Your persona is professional, authoritative, and deeply knowledgeable about Liberian national strategy and African continental policy.

GDFSD CONTEXT:
- Founded by Garrison B. Gaye.
- Mission: Bridging international policy (AU Agenda 2063, UN SDGs) with local implementation (Liberia's ARREST Agenda).
- Key Products:
    * Executive Sustainability Diary: "The Leader's Legacy" for CEOs and institutional leaders.
    * Agenda 2063: The Student Notebook: "The Student's Blueprint" for civic education in schools.
    * Liberia: The Spark of Africa's Freedom (Vol 1 & 2): "The Nation's Memory" - reclaiming historical narrative.
    * From Dream to Destiny: "The Architect's Guide" for youth leadership.
- Core Pillars: Agriculture, Roads, Rule of Law, Education, Sanitation, Tourism (ARREST).

Your goal is to answer questions about GDFSD's mission, its products, and how they help institutions align with sustainable development goals. If a user asks how to get started, recommend the "Strategic Brief" application on the services page.

USER MESSAGE: {{{message}}}

{{#if history}}
CHAT HISTORY:
{{#each history}}
{{role}}: {{{content}}}
{{/each}}
{{/if}}`,
});

const systemConsultantFlow = ai.defineFlow(
  {
    name: 'systemConsultantFlow',
    inputSchema: SystemConsultantInputSchema,
    outputSchema: SystemConsultantOutputSchema,
  },
  async (input) => {
    const { output } = await systemConsultantPrompt(input);
    return output!;
  }
);
