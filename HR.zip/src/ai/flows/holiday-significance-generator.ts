'use server';
/**
 * @fileOverview This file implements a Genkit flow for generating developmental significance reports or
 * sustainable action plans for African and Liberian holidays. It connects the holiday's context to
 * relevant sustainability frameworks (UN SDGs, AU Agenda 2063, Liberia's ARREST Agenda) and GDFSD initiatives.
 *
 * - generateHolidaySignificance - A function that triggers the AI to generate the report.
 * - HolidaySignificanceGeneratorInput - The input type for the generateHolidaySignificance function.
 * - HolidaySignificanceGeneratorOutput - The return type for the generateHolidaySignificance function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const HolidaySignificanceGeneratorInputSchema = z.object({
  holidayName: z.string().describe('The name of the African or Liberian holiday (e.g., "Africa Day", "Liberia Independence Day").'),
});
export type HolidaySignificanceGeneratorInput = z.infer<typeof HolidaySignificanceGeneratorInputSchema>;

const HolidaySignificanceGeneratorOutputSchema = z.object({
  title: z.string().describe('The title of the generated developmental significance report or sustainable action plan.'),
  report: z.string().describe('The AI-generated report or action plan, connecting the holiday to sustainability frameworks and GDFSD initiatives.'),
});
export type HolidaySignificanceGeneratorOutput = z.infer<typeof HolidaySignificanceGeneratorOutputSchema>;

export async function generateHolidaySignificance(input: HolidaySignificanceGeneratorInput): Promise<HolidaySignificanceGeneratorOutput> {
  return holidaySignificanceGeneratorFlow(input);
}

const holidaySignificancePrompt = ai.definePrompt({
  name: 'holidaySignificancePrompt',
  input: {schema: HolidaySignificanceGeneratorInputSchema},
  output: {schema: HolidaySignificanceGeneratorOutputSchema},
  prompt: `You are an expert in sustainable development, African policy, and Liberian national strategy.
Your task is to generate a concise and high-level "Developmental Significance Report" or "Sustainable Action Plan" for the given African or Liberian holiday.

The report should address the following points:
1.  **Historical and Cultural Significance**: Briefly explain the core meaning and background of the holiday.
2.  **Policy Alignment**: Connect the holiday's themes and values to relevant global, continental, and national frameworks:
    -   UN Sustainable Development Goals (SDGs)
    -   African Union Agenda 2063
    -   Liberia's ARREST Agenda (Agriculture, Roads, Rule of Law, Education, Sanitation, Tourism).
3.  **GDFSD Initiatives Integration**: Suggest how GDFSD's products (Executive Diary, Agenda 2063 Notebook, The Spark of Freedom, Dream to Destiny) and consultancy services align with and can advance the goals related to this holiday.
4.  **Actionable Insights**: Provide key takeaways or actionable recommendations for policymakers and educators.

Ensure the tone is professional, authoritative, and suitable for high-level stakeholders like government ministries and international partners.

Holiday: {{{holidayName}}}`,
});

const holidaySignificanceGeneratorFlow = ai.defineFlow(
  {
    name: 'holidaySignificanceGeneratorFlow',
    inputSchema: HolidaySignificanceGeneratorInputSchema,
    outputSchema: HolidaySignificanceGeneratorOutputSchema,
  },
  async (input) => {
    const {output} = await holidaySignificancePrompt(input);
    return output!;
  }
);
