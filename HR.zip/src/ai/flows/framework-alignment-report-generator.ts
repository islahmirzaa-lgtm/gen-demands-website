'use server';
/**
 * @fileOverview A Genkit flow to generate a preview of a "Recommended Framework Alignment Report".
 *
 * - generateFrameworkAlignmentReport - A function that generates a tailored report based on the selected sector.
 * - FrameworkAlignmentReportInput - The input type for the generateFrameworkAlignmentReport function.
 * - FrameworkAlignmentReportOutput - The return type for the generateFrameworkAlignmentReport function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const FrameworkAlignmentReportInputSchema = z.object({
  sector: z
    .enum(['Education', 'Finance', 'Agriculture'])
    .describe('The institutional sector for which to generate the report.'),
});
export type FrameworkAlignmentReportInput = z.infer<
  typeof FrameworkAlignmentReportInputSchema
>;

const FrameworkAlignmentReportOutputSchema = z.object({
  report: z
    .string()
    .describe('The AI-generated preview of the framework alignment report.'),
});
export type FrameworkAlignmentReportOutput = z.infer<
  typeof FrameworkAlignmentReportOutputSchema
>;

export async function generateFrameworkAlignmentReport(
  input: FrameworkAlignmentReportInput
): Promise<FrameworkAlignmentReportOutput> {
  return frameworkAlignmentReportGeneratorFlow(input);
}

const frameworkAlignmentReportPrompt = ai.definePrompt({
  name: 'frameworkAlignmentReportPrompt',
  input: {schema: FrameworkAlignmentReportInputSchema},
  output: {schema: FrameworkAlignmentReportOutputSchema},
  prompt: `You are an expert consultant for Generational Demands for Sustainable Development Inc. (GDFSD). Your mission is to bridge the gap between continental vision and local action, helping institutions align with sustainable development goals.

GDFSD offers the following flagship products and services:
- **Executive Sustainability Diary**: Positioned as "The Leader's Legacy." Helps with institutional performance, legacy building, and long-term strategic planning for leaders and CEOs.
- **Africa’s Agenda 2063: The Student Notebook**: Positioned as "The Student’s Blueprint." Fosters civic responsibility, Pan-Africanism, and integrates civic education into classrooms for students.
- **Liberia: The Spark of Africa’s Freedom**: Positioned as "The Nation’s Memory." Promotes national identity and historical awareness for researchers and youth.
- **From Dream to Destiny**: Positioned as "The Architect's Guide." (This product supports strategic planning and future visioning).
- **Institutional Consultancy Services**: Helps Ministries, NGOs, and other institutions align their internal planning with national, continental, and global sustainability frameworks (e.g., ARREST Agenda, AU Agenda 2063, UN SDGs, ECOWAS Vision 2050).
- **School Programs**: Focus on integrating civic education and sustainability principles into educational curricula.

Your task is to generate a concise preview of a "Recommended Framework Alignment Report" for an institution in the '{{{sector}}}' sector. This report should outline how GDFSD's products and services can support their specific sustainability objectives. Focus on the most relevant products and services for the given sector.

Sector: {{{sector}}}

--- Start of Report Preview ---

## Recommended Framework Alignment Report Preview for the {{{sector}}} Sector

**Introduction:**

This preview outlines how Generational Demands for Sustainable Development Inc. (GDFSD) can partner with institutions within the **{{{sector}}}** sector to advance their sustainability objectives and align with critical national, continental, and global frameworks.

**Key Opportunities & GDFSD Alignment:**

{{#ifEquals sector "Education"}}
Institutions in the Education sector are pivotal in shaping future generations. GDFSD offers:

*   **Africa’s Agenda 2063: The Student Notebook**: Directly integrates civic education and Pan-Africanism into classroom learning, fostering civic responsibility and a forward-looking perspective.
*   **Liberia: The Spark of Africa’s Freedom**: Provides historical context and promotes national identity, crucial for comprehensive educational curricula.
*   **Institutional Consultancy Services**: Supports educational leadership in developing sustainability-aligned curricula and strategic plans that resonate with national and international mandates like SDG 4 (Quality Education) and AU Agenda 2063.
*   **School Programs**: Tailored initiatives to embed sustainable development principles and civic engagement directly into the student experience.

**Impact:** By leveraging GDFSD's tools and expertise, educational institutions can cultivate informed, responsible, and globally-aware citizens, driving progress towards national development goals.
{{/ifEquals}}

{{#ifEquals sector "Finance"}}
Institutions in the Finance sector play a critical role in sustainable economic development and governance. GDFSD offers:

*   **Executive Sustainability Diary**: "The Leader's Legacy" provides a structured approach for executives to integrate sustainability into their daily operations, track institutional performance, and build a lasting legacy of responsible governance.
*   **From Dream to Destiny**: Supports strategic planning and future visioning, helping financial institutions to develop robust, long-term sustainability strategies.
*   **Institutional Consultancy Services**: Assists financial organizations in aligning investment strategies, reporting, and operational policies with national economic development plans, ethical frameworks, and global sustainability standards.

**Impact:** GDFSD enables financial institutions to enhance their governance, attract responsible investments, and contribute to a resilient and sustainable economic landscape.
{{/ifEquals}}

{{#ifEquals sector "Agriculture"}}
Institutions in the Agriculture sector are fundamental to food security, environmental stewardship, and rural development. GDFSD offers:

*   **Africa’s Agenda 2063: The Student Notebook**: Can be adapted to introduce sustainable farming concepts and environmental awareness to youth, fostering a future generation of responsible agricultural practices.
*   **Executive Sustainability Diary**: Provides a framework for agricultural leaders to plan and track sustainable land use, resource management, and operational efficiencies, ensuring long-term viability.
*   **Institutional Consultancy Services**: Guides agricultural ministries and organizations in developing policies and programs that align with sustainable agricultural practices, climate resilience goals, and food security mandates, such as SDG 2 (Zero Hunger).

**Impact:** GDFSD helps agricultural institutions cultivate sustainable practices, improve food security, and enhance resilience against environmental challenges.
{{/ifEquals}}

**Conclusion:**

This preview demonstrates GDFSD's capacity to deliver targeted solutions that empower institutions within the **{{{sector}}}** sector to achieve their sustainability goals and contribute effectively to broader national and international development agendas.

--- End of Report Preview ---`,
});

const frameworkAlignmentReportGeneratorFlow = ai.defineFlow(
  {
    name: 'frameworkAlignmentReportGeneratorFlow',
    inputSchema: FrameworkAlignmentReportInputSchema,
    outputSchema: FrameworkAlignmentReportOutputSchema,
  },
  async (input) => {
    const {output} = await frameworkAlignmentReportPrompt(input);
    return output!;
  }
);
